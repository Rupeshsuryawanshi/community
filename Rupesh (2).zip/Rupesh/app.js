var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var index = require('./routes/index');
var mysql = require('mysql');
var connection = require('express-myconnection');
var app = express();
var moment = require('moment-timezone');
//var Pushnotication = require('./pushnotication/fcm');   
  

moment.tz.setDefault("Europe/London");

moment().tz("Europe/Moscow").format();






app.use(function(req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});


app.use(connection(mysql, {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'survey'
}, 'request'));
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');
app.set('view engine', 'ejs');
// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json({limit: '500mb'}));
/*app.use(bodyParser.urlencoded({
    extended: false
}));*/
app.use(bodyParser.urlencoded({extended:true, limit:'50mb'}));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use("/ImagesFiles",express.static(__dirname +"/Images"));
app.use("/PdfFiles",express.static(__dirname +"/PdfFiles"));
app.use("/AADeliverys",express.static(__dirname +"/AADeliverys"));

app.use('/community/', index);


// catch 404 and forward to error handler
app.use(function(req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// error handler
app.use(function(err, req, res, next) {
    // set locals, only providing error in development
    res.locals.message = err.message;
    res.locals.error = req.app.get('env') === 'development' ? err : {};

    // render the error page
    res.status(err.status || 500);
    res.render('error');
});


app.listen(3000, function() {

    console.log("Server is start");
});



module.exports = app;