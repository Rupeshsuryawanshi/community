var express = require('express');
var multer = require('multer');
var router = express.Router();
var nodemailer = require('nodemailer'); 
var mysql = require('mysql')
const fetch = require("node-fetch");
const ejs=require('ejs');
var moment = require('moment-timezone');
var Pushnotication = require('./../pushnotication/fcm');
var escape = require('sql-escape');
 var asyncLoop = require('node-async-loop');
var fs = require("fs");

var smtpTransport = require("nodemailer-smtp-transport");

var transporter = nodemailer.createTransport(({
  host : "smtp.gmail.com",
  port: 587,
  secure: false,
  service: "gmail",
  auth : {
      user : "suryavanshi.r12@gmail.com",
      pass : "8982122202@r"
  }
}));
// Create Customer isUsersurveysLoggedIn
router.get('/Start', (req, res, next)=>{   
  try{
    var reqObj = req.body;
    req.getConnection(function(err,conn) {
      if (!!err) {
        console.error('SQL Connection error: ', err);
        return next(err);
    } //connection ckeck
     else {
      res.render('home') 
}
    })
  }
catch(ex){
            
     return next(ex);
   }             
})
router.post('/community',(req,res,next)=>{
  try{
    var reqObj = req.body;
    if(reqObj.email==undefined ||  reqObj.email==''){
        res.json({"status":'false',"message":'Request parameter is missing'});
        return false;
    }else{
      req.getConnection(function(err,conn) {
        if (!!err) {
          console.error('SQL Connection error: ', err);
          return next(err);
      } //connection ckeck
       else {
       conn.query("SELECT * FROM community WHERE name_community='"+reqObj.search+"'", function (err, result) {
  
      if (err) throw err;
      else{
        if(result.length>0){
        res.send({message:"Community alredy register"});
        }
        else{
          conn.query("INSERT INTO community (name_community) VALUES ('"+ req.body.search+"')", function (err, result2) {
            if(err){
              res.send({status:"false",msg:"invalid",data:err})
            } else{
  
        

          var msgContent = "<br>Community_name:"+req.body.search+"<br>purpose:"+req.body.purpose+"<br>Name:"+req.body.fname+"<br>email :"+req.body.email+"<br>Name :"+req.body.faname+"<br>email :"+req.body.email2+"";
  
          var mailOptions={
              from: req.body.email ,
      to : "suryavanshi.r12@gmail.com",
      subject : "Community ",
      html : msgContent
  }
  transporter.sendMail(mailOptions, function(error, response){
      if(error){
          console.log(error); 
      res.end("error");
      }else{
      res.end("sent");
      console.log(response); 
      }
  });//end of smtp

  res.set('Content-Type', 'application/javascript');
  res.render('testPage', { myVar :req.body});
        }
      })
      }
}
            
  
            })
  }
})
    }
  }
catch(ex){
    console.error("Internal error:"+ex);
    return next(ex)
    }
})

module.exports = router;