var express = require('express');
var multer = require('multer');
var router = express.Router();
var nodemailer = require('nodemailer');
var moment = require('moment-timezone');

router.get('/', function(req, res, next) {
    res.sendFile(__dirname + "/index.html");
});

module.exports = router;

// Api for login

router.post('/userLogin', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    if (reqObj.username == '') {
        res.json({
            "status": "error",
            "message": "username should not be blank"
        });
        return false;
    } else if (reqObj.username == undefined) {
        res.json({
            "status": "error",
            "message": "username is required field"
        });
        return false;
    } else if (reqObj.password == '') {
        res.json({
            "status": "error",
            "message": "password should not be blank"
        });
        return false;
    } else if (reqObj.password == undefined) {
        res.json({
            "status": "error",
            "message": "password is required field"
        });
        return false;
    } else if (reqObj.user_type == '') {
        res.json({
            "status": "error",
            "message": "user_type should not be blank"
        });
        return false;
    } else if (reqObj.user_type == undefined) {
        res.json({
            "status": "error",
            "message": "user_type is required field"
        });
        return false;
    } else if (reqObj.app_id == '') {
        res.json({
            "status": "error",
            "message": "app_id should not be blank"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else {

        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {
                    //res.send("SELECT * from `userinfo` where `username`="+reqObj.username+" and `password`="+reqObj.password+" and `user_type`="+reqObj.user_type+" ");
                    var query = conn.query("SELECT * from `userinfo` where `username`='" + reqObj.username + "' and `password`='" + reqObj.password + "' and `user_type`='" + reqObj.user_type + "' and `app_id`='" + reqObj.app_id + "' ", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false',
                                "msg": 'Wrong username or password'
                            });

                        } else {
                            res.json({
                                "status": 'true',
                                "msg": 'Authenication Successful',
                                "response": result
                            });
                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});



// Create Gallary Image
router.post('/createGallary', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    if (reqObj.folder_name == '') {
        res.json({
            "status": "error",
            "message": "folder_name should not be blank"
        });
        return false;
    } else if (reqObj.folder_name == undefined) {
        res.json({
            "status": "error",
            "message": "folder_name is required field"
        });
        return false;
    } else if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.manager_id == '' || reqObj.manager_id == 0) {
        res.json({
            "status": "error",
            "message": "manager_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.manager_id == undefined) {
        res.json({
            "status": "error",
            "message": "manager_id is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("insert into `gallary` (`folder_name`,`app_id`,`manager_id`) values('" + reqObj.folder_name + "','" + reqObj.app_id + "','" + reqObj.manager_id + "')", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false',
                                "msg": 'Not create gallary'
                            });

                        } else {
                            res.json({
                                "status": 'true',
                                "msg": 'gallary created',
                                "response": result
                            });
                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});

//Get gallary

router.post('/getGallary', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);

    if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("select * from `gallary` where `app_id`='" + reqObj.app_id + "' order by `id` desc ", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false'
                            });

                        } else {
                            res.json({
                                "status": 'true',
                                "response": result
                            });
                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});


//Get gallary Images

router.post('/getGallaryImages', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    if (reqObj.gallary_id == '' || reqObj.gallary_id == 0) {
        res.json({
            "status": "error",
            "message": "gallary_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.gallary_id == undefined) {
        res.json({
            "status": "error",
            "message": "gallary_id is required field"
        });
        return false;
    } else if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("select * from `gallary_images` where `app_id`='" + reqObj.app_id + "' AND `gallary_id`='" + reqObj.gallary_id + "' ORDER BY `position` ASC", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false'
                            });

                        } else {
                            res.json({
                                "status": 'true',
                                "response": result
                            });
                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});

// Add image gallary
var positionId = '';
router.post('/addGallaryImage', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    if (reqObj.gallary_id == '' || reqObj.gallary_id == 0) {
        res.json({
            "status": "error",
            "message": "gallary_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.gallary_id == undefined) {
        res.json({
            "status": "error",
            "message": "gallary_id is required field"
        });
        return false;
    } else if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.manager_id == '' || reqObj.manager_id == 0) {
        res.json({
            "status": "error",
            "message": "manager_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.manager_id == undefined) {
        res.json({
            "status": "error",
            "message": "manager_id is required field"
        });
        return false;
    } else if (reqObj.image_url == '') {
        res.json({
            "status": "error",
            "message": "image_url should not be blank"
        });
        return false;
    } else if (reqObj.image_url == undefined) {
        res.json({
            "status": "error",
            "message": "image_url is required field"
        });
        return false;
    } else {

        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("select ifnull(max(position)+1,1) as position from gallary_images where `gallary_id`='" + reqObj.gallary_id + "'", function(err, result1) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }

                        var query = conn.query("insert into `gallary_images` (`gallary_id`,`image_url`,`app_id`,`manager_id`,`position`,`img_desc`) values('" + reqObj.gallary_id + "','" + reqObj.image_url + "','" + reqObj.app_id + "','" + reqObj.manager_id + "','" + result1[0].position + "','" + reqObj.img_desc + "')", function(err, result) {
                            if (!!err) {
                                console.error('SQL error: ', err);
                                return next(err);
                            }
                            if (result == '') {

                                res.json({
                                    "status": 'false',
                                    "msg": 'image is not inserted'
                                });

                            } else {

                                var query = conn.query("UPDATE `gallary` SET `image_url`='" + reqObj.image_url + "' where `id`='" + reqObj.gallary_id + "' ", function(err, result2) {
                                    if (!!err) {
                                        console.error('SQL error: ', err);
                                        return next(err);
                                    }
                                });

                                res.json({
                                    "status": 'true',
                                    "msg": 'image is inserted',
                                    "response": result
                                });
                            }

                        });
                    });

                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});



// Delete gallary
router.post('/deleteGallary', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);

    if (reqObj.gallary_id == '' || reqObj.gallary_id == 0) {
        res.json({
            "status": "error",
            "message": "gallary_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.gallary_id == undefined) {
        res.json({
            "status": "error",
            "message": "gallary_id is required field"
        });
        return false;
    } else if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("DELETE FROM `gallary` where `id`='" + reqObj.gallary_id + "' AND `app_id`='" + reqObj.app_id + "'", function(err, result1) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }

                        var query = conn.query("DELETE FROM `gallary_images` where `gallary_id`='" + reqObj.gallary_id + "' AND `app_id`='" + reqObj.app_id + "'", function(err, result) {
                            if (!!err) {
                                console.error('SQL error: ', err);
                                return next(err);
                            }
                            if (result == '') {

                                res.json({
                                    "status": 'false',
                                    "msg": 'gallary is not Deleted'
                                });

                            } else {

                                res.json({
                                    "status": 'true',
                                    "msg": 'Gallary is Deleted'
                                });
                            }

                        });
                    });

                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});



// Delete gallary Images
router.post('/deleteGallaryImages', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    if (reqObj.gallary_id == '' || reqObj.gallary_id == 0) {
        res.json({
            "status": "error",
            "message": "gallary_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.gallary_id == undefined) {
        res.json({
            "status": "error",
            "message": "gallary_id is required field"
        });
        return false;
    } else if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.image_id == '' || reqObj.image_id == 0) {
        res.json({
            "status": "error",
            "message": "image_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.image_id == undefined) {
        res.json({
            "status": "error",
            "message": "image_id is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("DELETE FROM `gallary_images` where `id`='" + reqObj.image_id + "' AND `app_id`='" + reqObj.app_id + "'", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false',
                                "msg": 'Image is not Deleted'
                            });

                        } else {
                            var query = conn.query("UPDATE `gallary` SET `image_url`='' where (SELECT COUNT(`id`)  FROM `gallary_images` where `gallary_id`='" + reqObj.gallary_id + "')=0 AND `id`='" + reqObj.gallary_id + "'", function(err, result2) {
                                if (!!err) {
                                    console.error('SQL error: ', err);
                                    return next(err);
                                }
                            });

                            res.json({
                                "status": 'true',
                                "msg": 'image is Deleted'
                            });
                        }

                    });

                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});


// Sorting gallary Images
router.post('/sortingGallaryImages', function(req, res, next) {
    var reqObj = req.body;

    reqObj = JSON.parse(reqObj.response);
    console.log(reqObj);

    try {

        req.getConnection(function(err, conn) {
            if (!!err) {
                console.error('SQL Connection error: ', err);
                return next(err);
            } else {
                var j = 0;
                for (var i = 0; i < reqObj.length; i++) {
                    j++;

                    var query = conn.query("update `gallary_images` set `position`='" + j + "' where `id`='" + reqObj[i].id + "' AND `app_id`='" + reqObj[i].app_id + "' AND `gallary_id`='" + reqObj[i].gallary_id + "'", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }

                    });
                }

                res.json({
                    "status": 'true'
                });
            }

        });
    } catch (ex) {
        console.error("Internal error:" + ex);
        return next(ex);
    }
});

// Create events
router.post('/createEvents', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);

    if (reqObj.event_name == '') {
        res.json({
            "status": "error",
            "message": "event_name should not be blank"
        });
        return false;
    } else if (reqObj.event_name == undefined) {
        res.json({
            "status": "error",
            "message": "event_name is required field"
        });
        return false;
    } else if (reqObj.date == '') {
        res.json({
            "status": "error",
            "message": "date should not be blank"
        });
        return false;
    } else if (reqObj.date == undefined) {
        res.json({
            "status": "error",
            "message": "date is required field"
        });
        return false;
    } else if (reqObj.manager_id == '' || reqObj.manager_id == 0) {
        res.json({
            "status": "error",
            "message": "manager_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.manager_id == undefined) {
        res.json({
            "status": "error",
            "message": "manager_id is required field"
        });
        return false;
    } else if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("insert into `events` (`event_name`,`description`,`date`,`manager_id`,`app_id`) values('" + reqObj.event_name + "','" + reqObj.description + "','" + reqObj.date + "','" + reqObj.manager_id + "','" + reqObj.app_id + "')", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false',
                                "msg": 'Not create event'
                            });

                        } else {
                            var lastInsertID = result.insertId;
                            var timestampLength = (JSON.parse(reqObj.timestamp)).length;
                            var timestamp = JSON.parse(reqObj.timestamp);
                            for (var i = 0; i < timestampLength; i++) {
                                var query = conn.query("update `events_images` set `event_id`='" + lastInsertID + "',`status`=1 where `timestamp`='" + timestamp[i].timestampId + "' AND `app_id`='" + reqObj.app_id + "' AND `manager_id`='" + reqObj.manager_id + "'", function(err, result) {
                                    if (!!err) {
                                        console.error('SQL error: ', err);
                                        return next(err);
                                    }

                                });
                            }
                            res.json({
                                "status": 'true'
                            });
                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});

//upload events images

router.post('/uploadEventsImages', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);

    if (reqObj.timestamp == '') {
        res.json({
            "status": "error",
            "message": "timestamp should not be blank"
        });
        return false;
    } else if (reqObj.timestamp == undefined) {
        res.json({
            "status": "error",
            "message": "timestamp is required field"
        });
        return false;
    } else if (reqObj.image_url == '') {
        res.json({
            "status": "error",
            "message": "image_url should not be blank"
        });
        return false;
    } else if (reqObj.image_url == undefined) {
        res.json({
            "status": "error",
            "message": "image_url is required field"
        });
        return false;
    } else if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.manager_id == '' || reqObj.manager_id == 0) {
        res.json({
            "status": "error",
            "message": "manager_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.manager_id == undefined) {
        res.json({
            "status": "error",
            "message": "manager_id is required field"
        });
        return false;
    } else {

        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("insert into `events_images` (`timestamp`,`image`,`app_id`,`manager_id`) values('" + reqObj.timestamp + "','" + reqObj.image_url + "','" + reqObj.app_id + "','" + reqObj.manager_id + "')", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false'
                            });

                        } else {
                            res.json({
                                "status": 'true'
                            });
                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});




//Get events

router.post('/getEvents', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);

    if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("SELECT * FROM (SELECT a.event_id,a.id, a.image, b.event_name, b.date, b.manager_id, b.app_id, b.description FROM events_images as a,events as b where a.event_id = b.id and b.app_id = a.app_id and b.app_id ='" + reqObj.app_id + "' ORDER BY a.id DESC) AS t GROUP BY event_id", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false'
                            });

                        } else {
                            res.json({
                                "status": 'true',
                                "response": result
                            });


                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});


//Get events Images

router.post('/getEventsImages', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.event_id == '' || reqObj.event_id == 0) {
        res.json({
            "status": "error",
            "message": "event_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.event_id == undefined) {
        res.json({
            "status": "error",
            "message": "event_id is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("select * from `events_images` where `app_id`='" + reqObj.app_id + "' AND  `event_id`='" + reqObj.event_id + "' ORDER BY `id` ASC", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false'
                            });

                        } else {
                            res.json({
                                "status": 'true',
                                "response": result
                            });


                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});

//Edit events

router.post('/editEvents', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    if (reqObj.event_id == '' || reqObj.event_id == 0) {
        res.json({
            "status": "error",
            "message": "event_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.event_id == undefined) {
        res.json({
            "status": "error",
            "message": "event_id is required field"
        });
        return false;
    } else if (reqObj.event_name == '') {
        res.json({
            "status": "error",
            "message": "event_name should not be blank or 0"
        });
        return false;
    } else if (reqObj.event_name == undefined) {
        res.json({
            "status": "error",
            "message": "event_name is required field"
        });
        return false;
    } else if (reqObj.date == '') {
        res.json({
            "status": "error",
            "message": "date should not be blank or 0"
        });
        return false;
    } else if (reqObj.date == undefined) {
        res.json({
            "status": "error",
            "message": "date is required field"
        });
        return false;
    } else if (reqObj.manager_id == '' || reqObj.manager_id == 0) {
        res.json({
            "status": "error",
            "message": "manager_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.manager_id == undefined) {
        res.json({
            "status": "error",
            "message": "manager_id is required field"
        });
        return false;
    } else if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.description == undefined) {
        res.json({
            "status": "error",
            "message": "description is required field"
        });
        return false;
    } else if (reqObj.timestamp == undefined) {
        res.json({
            "status": "error",
            "message": "timestamp is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("update `events` set `event_name`='" + reqObj.event_name + "',`description`='" + reqObj.description + "',`date`='" + reqObj.date + "' where `app_id`='" + reqObj.app_id + "' AND `id`='" + reqObj.event_id + "' AND `manager_id`='" + reqObj.manager_id + "'", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false'
                            });

                        } else {
                            var timestampLength = JSON.parse(reqObj.timestamp).length;
                            var timestamp = JSON.parse(reqObj.timestamp);
                            if (timestampLength > 0) {
                                for (var i = 0; i < timestampLength; i++) {
                                    var query = conn.query("update `events_images` set `event_id`='" + reqObj.event_id + "',`status`=1 where `timestamp`='" + timestamp[i].timestampId + "' AND `app_id`='" + reqObj.app_id + "' AND `manager_id`='" + reqObj.manager_id + "'", function(err, result) {
                                        if (!!err) {
                                            console.error('SQL error: ', err);
                                            return next(err);
                                        }

                                    });
                                }
                                res.json({
                                    "status": 'true'
                                });
                            } else {
                                res.json({
                                    "status": 'true'
                                });
                            }

                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});


//Delete events

router.post('/deleteEvents', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    if (reqObj.manager_id == '' || reqObj.manager_id == 0) {
        res.json({
            "status": "error",
            "message": "manager_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.manager_id == undefined) {
        res.json({
            "status": "error",
            "message": "manager_id is required field"
        });
        return false;
    } else if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.event_id == '' || reqObj.event_id == 0) {
        res.json({
            "status": "error",
            "message": "event_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.event_id == undefined) {
        res.json({
            "status": "error",
            "message": "event_id is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("DELETE from `events` where `app_id`='" + reqObj.app_id + "' AND `id`='" + reqObj.event_id + "' AND `manager_id`='" + reqObj.manager_id + "'", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false'
                            });

                        } else {
                            var query = conn.query("DELETE from `events_images` where `event_id`='" + reqObj.event_id + "'", function(err, result) {
                                if (!!err) {
                                    console.error('SQL error: ', err);
                                    return next(err);
                                }
                                if (result == '') {

                                    res.json({
                                        "status": 'false'
                                    });

                                } else {
                                    res.json({
                                        "status": 'true'
                                    });
                                }

                            });
                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});

//contactUsEmail

router.post('/contactUsEmail', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    var address = req.body.address;
    var pin = req.body.pin;
    var phoneno = req.body.phoneno;
    var email = req.body.email;
    var description = req.body.description;
    var app_id = req.body.app_id;
    var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'mindcrewtest1001@gmail.com',
            pass: 'mahi1990**'
        }
    });



    var mailOptions = {
        from: 'mindcrewtest1001@gmail.com',
        to: 'rahul.ghodke61@gmail.com',
        subject: 'FitnessApp support!',
        text: "",
        html: "<div style='border: solid 11px;font-size: 15px;'><div style='background-color:white;padding: 19px;'><br>Dear,<br><br><table><tr></td><b>Email</b></td><td>:</td><td>" + email + "</td></tr><tr><td><b>Address</b></td><td>:</td><td>" + address + "</td></tr><tr><td><b>Pin</b></td><td>:</td><td>" + pin + "</td></tr><tr><td><b>Phone number</b></td><td>:</td><td>" + phoneno + "</td></tr><tr><td><b>Description</b></td><td>:</td><td>" + description + "</td></tr></table><br><br>Thanks</div></div>"
    };

    transporter.sendMail(mailOptions, function(error, info) {

        if (error) {
            // console.log(error);
            res.json({
                "status": "error",
                "message": "Something, went wrong. Please try again!"
            });
        } else {
            res.json({
                "status": "true",
                "message": "Email send Successfully!"
            });

        }
    });
});


//upload multiple images

var Storage = multer.diskStorage({
    destination: function(req, file, callback) {
        var reqObj = req.body;
        console.log(reqObj);
        callback(null, "./Images");
    },
    filename: function(req, file, callback) {
        reqObj = req.headers;
       
            if (reqObj.upload_type == 'event') {
                try {

                    req.getConnection(function(err, conn) {
                        if (!!err) {
                            console.error('SQL Connection error: ', err);
                            return next(err);
                        } else {

                            var query = conn.query("insert into `events_images` (`timestamp`,`image`,`app_id`,`manager_id`) values('" + reqObj.timestamp + "','" + reqObj.timestamp + "_" + file.originalname + "','" + reqObj.app_id + "','" + reqObj.manager_id + "')", function(err, result) {
                                if (!!err) {
                                    console.error('SQL error: ', err);
                                    return next(err);
                                }

                            });
                        }

                    });
                } catch (ex) {
                    console.error("Internal error:" + ex);
                    return next(ex);
                }
            }
            if (reqObj.upload_type == "trainer") {
                try {

                    req.getConnection(function(err, conn) {
                        if (!!err) {
                            console.error('SQL Connection error: ', err);
                            return next(err);
                        } else {

                            var query = conn.query("insert into `trainer_images` (`timestamp`,`image`,`app_id`,`manager_id`) values('" + reqObj.timestamp + "','" + reqObj.timestamp + "_" + file.originalname + "','" + reqObj.app_id + "','" + reqObj.manager_id + "')", function(err, result) {
                                if (!!err) {
                                    console.error('SQL error: ', err);
                                    return next(err);
                                }


                            });
                        }

                    });
                } catch (ex) {
                    console.error("Internal error:" + ex);
                    return next(ex);
                }
            }
            if (reqObj.upload_type == "lesson") {
                try {

                    req.getConnection(function(err, conn) {
                        if (!!err) {
                            console.error('SQL Connection error: ', err);
                            return next(err);
                        } else {

                            var query = conn.query("insert into `tranning_lesson_images` (`timestamp`,`image`,`app_id`,`manager_id`) values('" + reqObj.timestamp + "','" + reqObj.timestamp + "_" + file.originalname + "','" + reqObj.app_id + "','" + reqObj.manager_id + "')", function(err, result) {
                                if (!!err) {
                                    console.error('SQL error: ', err);
                                    return next(err);
                                }


                            });
                        }

                    });
                } catch (ex) {
                    console.error("Internal error:" + ex);
                    return next(ex);
                }
            }
            if (reqObj.upload_type == "coupon") {
                try {

                    req.getConnection(function(err, conn) {
                        if (!!err) {
                            console.error('SQL Connection error: ', err);
                            return next(err);
                        } else {

                            var query = conn.query("insert into `coupon_images` (`timestamp`,`image`,`app_id`,`manager_id`) values('" + reqObj.timestamp + "','" + reqObj.timestamp + "_" + file.originalname + "','" + reqObj.app_id + "','" + reqObj.manager_id + "')", function(err, result) {
                                if (!!err) {
                                    console.error('SQL error: ', err);
                                    return next(err);
                                }


                            });
                        }

                    });
                } catch (ex) {
                    console.error("Internal error:" + ex);
                    return next(ex);
                }
            }
            if (reqObj.upload_type == "gallary") {

                try {

                    req.getConnection(function(err, conn) {
                        if (!!err) {
                            console.error('SQL Connection error: ', err);
                            return next(err);
                        } else {

                            var query = conn.query("select ifnull(max(position)+1,1) as position from gallary_images where `gallary_id`='" + reqObj.gallary_id + "'", function(err, result1) {
                                if (!!err) {
                                    console.error('SQL error: ', err);
                                    return next(err);
                                }

                                var query = conn.query("insert into `gallary_images` (`gallary_id`,`image_url`,`app_id`,`manager_id`,`position`,`img_desc`) values('" + reqObj.gallary_id + "','" + reqObj.timestamp + "_" + file.originalname + "','" + reqObj.app_id + "','" + reqObj.manager_id + "','" + result1[0].position + "','" + reqObj.img_desc + "')", function(err, result) {
                                    if (!!err) {
                                        console.error('SQL error: ', err);
                                        return next(err);
                                    }
                                    if (result == '') {

                                        res.json({
                                            "status": 'false',
                                            "msg": 'image is not inserted'
                                        });

                                    } else {

                                        var query = conn.query("UPDATE `gallary` SET `image_url`='" + reqObj.timestamp + "_" + file.originalname + "' where `id`='" + reqObj.gallary_id + "' ", function(err, result2) {
                                            if (!!err) {
                                                console.error('SQL error: ', err);
                                                return next(err);
                                            }
                                        });

                                    }

                                });
                            });

                        }

                    });
                } catch (ex) {
                    console.error("Internal error:" + ex);
                    return next(ex);
                }
            }

     callback(null, reqObj.timestamp + "_" + file.originalname);
    }
});

var upload = multer({
    storage: Storage
}).array("imgUploader", 1);

router.post("/Upload", function(req, res) {

    upload(req, res, function(err) {
        if (err) {
            return res.end("Something went wrong!");
        }
        //console.log("File uploaded sucessfully!.");
        res.json({
            "status": "true",
            "message": "File uploaded sucessfully!"
        });
        return res.end("File uploaded sucessfully!.");
    });
});



// Create Trainer
router.post('/addTrainer', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    try {

        req.getConnection(function(err, conn) {
            if (!!err) {
                console.error('SQL Connection error: ', err);
                return next(err);
            } else {

                var query = conn.query("insert into `trainer` (`trainer_name`,`phone_no`,`description`,`manager_id`,`app_id`) values('" + reqObj.trainer_name + "','" + reqObj.phone_no + "','" + reqObj.description + "','" + reqObj.manager_id + "','" + reqObj.app_id + "')", function(err, result) {
                    if (!!err) {
                        console.error('SQL error: ', err);
                        return next(err);
                    }
                    if (result == '') {

                        res.json({
                            "status": 'false',
                            "msg": 'Not create Trainer'
                        });

                    } else {
                        var lastInsertID = result.insertId;
                        var timestampLength = (JSON.parse(reqObj.timestamp)).length;
                        var timestamp = JSON.parse(reqObj.timestamp);
                        // var timestampLength = (reqObj.timestamp).length;
                        // var timestamp = reqObj.timestamp;
                        for (var i = 0; i < timestampLength; i++) {
                            var query = conn.query("update `trainer_images` set `trainer_id`='" + lastInsertID + "',`status`=1 where `timestamp`='" + timestamp[i].timestampId + "' AND `app_id`='" + reqObj.app_id + "' AND `manager_id`='" + reqObj.manager_id + "'", function(err, result) {
                                if (!!err) {
                                    console.error('SQL error: ', err);
                                    return next(err);
                                }

                            });
                        }
                        res.json({
                            "status": 'true'
                        });
                    }

                });
            }

        });
    } catch (ex) {
        console.error("Internal error:" + ex);
        return next(ex);
    }
});

//upload events images

router.post('/uploadTrainerImages', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    try {

        req.getConnection(function(err, conn) {
            if (!!err) {
                console.error('SQL Connection error: ', err);
                return next(err);
            } else {

                var query = conn.query("insert into `trainer_images` (`timestamp`,`image`,`app_id`,`manager_id`) values('" + reqObj.timestamp + "','" + reqObj.image_url + "','" + reqObj.app_id + "','" + reqObj.manager_id + "')", function(err, result) {
                    if (!!err) {
                        console.error('SQL error: ', err);
                        return next(err);
                    }
                    if (result == '') {

                        res.json({
                            "status": 'false'
                        });

                    } else {
                        res.json({
                            "status": 'true'
                        });
                    }

                });
            }

        });
    } catch (ex) {
        console.error("Internal error:" + ex);
        return next(ex);
    }
});


//Get Trainer

router.post('/getTrainer', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    try {

        req.getConnection(function(err, conn) {
            if (!!err) {
                console.error('SQL Connection error: ', err);
                return next(err);
            } else {

                var query = conn.query("SELECT * FROM (SELECT a.trainer_id,a.id, a.image, b.trainer_name, b.description, b.phone_no, b.manager_id, b.app_id FROM trainer_images as a,trainer as b where a.trainer_id = b.id and b.app_id = a.app_id and b.app_id ='" + reqObj.app_id + "' ORDER BY a.id DESC) AS t GROUP BY trainer_id", function(err, result) {
                    if (!!err) {
                        console.error('SQL error: ', err);
                        return next(err);
                    }
                    if (result == '') {

                        res.json({
                            "status": 'false'
                        });

                    } else {
                        res.json({
                            "status": 'true',
                            "response": result
                        });


                    }

                });
            }

        });
    } catch (ex) {
        console.error("Internal error:" + ex);
        return next(ex);
    }
});


//Get Trainer Images

router.post('/getTrainerImages', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    try {

        req.getConnection(function(err, conn) {
            if (!!err) {
                console.error('SQL Connection error: ', err);
                return next(err);
            } else {

                var query = conn.query("select * from `trainer_images` where `app_id`='" + reqObj.app_id + "' AND  `trainer_id`='" + reqObj.trainer_id + "' ORDER BY `id` ASC", function(err, result) {
                    if (!!err) {
                        console.error('SQL error: ', err);
                        return next(err);
                    }
                    if (result == '') {

                        res.json({
                            "status": 'false'
                        });

                    } else {
                        res.json({
                            "status": 'true',
                            "response": result
                        });


                    }

                });
            }

        });
    } catch (ex) {
        console.error("Internal error:" + ex);
        return next(ex);
    }
});

//Delete Trainer

router.post('/deleteTrainer', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    try {

        req.getConnection(function(err, conn) {
            if (!!err) {
                console.error('SQL Connection error: ', err);
                return next(err);
            } else {

                var query = conn.query("DELETE from `trainer` where `app_id`='" + reqObj.app_id + "' AND `id`='" + reqObj.trainer_id + "' AND `manager_id`='" + reqObj.manager_id + "'", function(err, result) {
                    if (!!err) {
                        console.error('SQL error: ', err);
                        return next(err);
                    }
                    if (result == '') {

                        res.json({
                            "status": 'false'
                        });

                    } else {
                        var query = conn.query("DELETE from `trainer_images` where `trainer_id`='" + reqObj.trainer_id + "'", function(err, result) {
                            if (!!err) {
                                console.error('SQL error: ', err);
                                return next(err);
                            }
                            if (result == '') {

                                res.json({
                                    "status": 'false'
                                });

                            } else {
                                res.json({
                                    "status": 'true'
                                });
                            }

                        });
                    }

                });
            }

        });
    } catch (ex) {
        console.error("Internal error:" + ex);
        return next(ex);
    }
});

//Edit Trainer

router.post('/editTrainer', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    try {

        req.getConnection(function(err, conn) {
            if (!!err) {
                console.error('SQL Connection error: ', err);
                return next(err);
            } else {

                var query = conn.query("update `trainer` set `trainer_name`='" + reqObj.trainer_name + "',`phone_no`='" + reqObj.phone_no + "',`description`='" + reqObj.description + "' where `app_id`='" + reqObj.app_id + "' AND `id`='" + reqObj.trainer_id + "' AND `manager_id`='" + reqObj.manager_id + "'", function(err, result) {
                    if (!!err) {
                        console.error('SQL error: ', err);
                        return next(err);
                    }
                    if (result == '') {

                        res.json({
                            "status": 'false'
                        });

                    } else {
                        var timestampLength = (JSON.parse(reqObj.timestamp)).length;
                        var timestamp = JSON.parse(reqObj.timestamp);
                        // var timestampLength = (reqObj.timestamp).length;
                        // var timestamp = reqObj.timestamp;
                        if (timestampLength > 0) {
                            for (var i = 0; i < timestampLength; i++) {
                                var query = conn.query("update `trainer_images` set `trainer_id`='" + reqObj.trainer_id + "',`status`=1 where `timestamp`='" + timestamp[i].timestampId + "' AND `app_id`='" + reqObj.app_id + "' AND `manager_id`='" + reqObj.manager_id + "'", function(err, result) {
                                    if (!!err) {
                                        console.error('SQL error: ', err);
                                        return next(err);
                                    }

                                });
                            }
                            res.json({
                                "status": 'true'
                            });
                        } else {
                            res.json({
                                "status": 'true'
                            });
                        }

                    }

                });
            }

        });
    } catch (ex) {
        console.error("Internal error:" + ex);
        return next(ex);
    }
});


// Create Training Lesson
router.post('/createTrainingLesson', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);

    if (reqObj.lesson_name == '') {
        res.json({
            "status": "error",
            "message": "lesson_name should not be blank"
        });
        return false;
    } else if (reqObj.lesson_name == undefined) {
        res.json({
            "status": "error",
            "message": "lesson_name is required field"
        });
        return false;
    } else if (reqObj.date == '') {
        res.json({
            "status": "error",
            "message": "date should not be blank"
        });
        return false;
    } else if (reqObj.date == undefined) {
        res.json({
            "status": "error",
            "message": "date is required field"
        });
        return false;
    } else if (reqObj.lesson_startTime == '') {
        res.json({
            "status": "error",
            "message": "lesson_startTime should not be blank"
        });
        return false;
    } else if (reqObj.lesson_startTime == undefined) {
        res.json({
            "status": "error",
            "message": "lesson_startTime is required field"
        });
        return false;
    } else if (reqObj.lesson_endTime == '') {
        res.json({
            "status": "error",
            "message": "lesson_endTime should not be blank"
        });
        return false;
    } else if (reqObj.lesson_endTime == undefined) {
        res.json({
            "status": "error",
            "message": "lesson_endTime is required field"
        });
        return false;
    } else if (reqObj.manager_id == '' || reqObj.manager_id == 0) {
        res.json({
            "status": "error",
            "message": "manager_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.manager_id == undefined) {
        res.json({
            "status": "error",
            "message": "manager_id is required field"
        });
        return false;
    } else if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.lesson_seats == '' || reqObj.lesson_seats == 0) {
        res.json({
            "status": "error",
            "message": "lesson_seats should not be blank or 0"
        });
        return false;
    } else if (reqObj.lesson_seats == undefined) {
        res.json({
            "status": "error",
            "message": "lesson_seats is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("insert into `tranning_lesson` (`lesson_name`,`lesson_description`,`lesson_date`,`lesson_startTime`,`lesson_endTime`,`manager_id`,`app_id`,`lesson_seats`) values('" + reqObj.lesson_name + "','" + reqObj.description + "','" + reqObj.date + "','" + reqObj.lesson_startTime + "','" + reqObj.lesson_endTime + "','" + reqObj.manager_id + "','" + reqObj.app_id + "','" + reqObj.lesson_seats + "')", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false',
                                "msg": 'Not create event'
                            });

                        } else {
                            var lastInsertID = result.insertId;
                            var timestampLength = (JSON.parse(reqObj.timestamp)).length;
                            var timestamp = JSON.parse(reqObj.timestamp);
                            // var timestampLength = (reqObj.timestamp).length;
                            // var timestamp = reqObj.timestamp;
                            for (var i = 0; i < timestampLength; i++) {
                                var query = conn.query("update `tranning_lesson_images` set `lesson_id`='" + lastInsertID + "',`status`=1 where `timestamp`='" + timestamp[i].timestampId + "' AND `app_id`='" + reqObj.app_id + "' AND `manager_id`='" + reqObj.manager_id + "'", function(err, result) {
                                    if (!!err) {
                                        console.error('SQL error: ', err);
                                        return next(err);
                                    }

                                });
                            }
                            res.json({
                                "status": 'true'
                            });
                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});

//upload Lesson images

router.post('/uploadLessonsImages', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);

    if (reqObj.timestamp == '') {
        res.json({
            "status": "error",
            "message": "timestamp should not be blank"
        });
        return false;
    } else if (reqObj.timestamp == undefined) {
        res.json({
            "status": "error",
            "message": "timestamp is required field"
        });
        return false;
    } else if (reqObj.image_url == '') {
        res.json({
            "status": "error",
            "message": "image_url should not be blank"
        });
        return false;
    } else if (reqObj.image_url == undefined) {
        res.json({
            "status": "error",
            "message": "image_url is required field"
        });
        return false;
    } else if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.manager_id == '' || reqObj.manager_id == 0) {
        res.json({
            "status": "error",
            "message": "manager_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.manager_id == undefined) {
        res.json({
            "status": "error",
            "message": "manager_id is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("insert into `tranning_lesson_images` (`timestamp`,`image`,`app_id`,`manager_id`) values('" + reqObj.timestamp + "','" + reqObj.image_url + "','" + reqObj.app_id + "','" + reqObj.manager_id + "')", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false'
                            });

                        } else {
                            res.json({
                                "status": 'true'
                            });
                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});


//Get Lesson

router.post('/getLessons', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);

    if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.date == '') {
        res.json({
            "status": "error",
            "message": "date should not be blank"
        });
        return false;
    } else if (reqObj.date == undefined) {
        res.json({
            "status": "error",
            "message": "date is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {
                    if (reqObj.customer_id == '' || reqObj.customer_id == undefined) {
                        var query = conn.query("SELECT * FROM (SELECT a.lesson_id, b.lesson_name, b.lesson_date, b.manager_id, b.app_id, b.lesson_description,b.lesson_startTime,b.lesson_endTime,b.lesson_seats FROM tranning_lesson_images as a,tranning_lesson as b where a.lesson_id = b.id and b.app_id = a.app_id and b.app_id ='" + reqObj.app_id + "' and b.lesson_date='" + reqObj.date + "' ORDER BY a.id DESC) AS t GROUP BY lesson_id", function(err, result) {
                            if (!!err) {
                                console.error('SQL error: ', err);
                                return next(err);
                            }
                            if (result == '') {

                                res.json({
                                    "status": 'true',
                                    "message": 'no data found',
                                    "response": result
                                });

                            } else {
                                res.json({
                                    "status": 'true',
                                    "message": "data found",
                                    "response": result
                                });


                            }

                        });
                    } else {
                        var query = conn.query("select lesson.id as lesson_id,lesson.lesson_name,lesson.lesson_date,lesson.lesson_startTime,lesson.lesson_endTime,lesson.lesson_seats,lesson.lesson_description,lesson_usage.book_date_time,(select COUNT(id) from tranning_lesson_usage where `status`=1) as attend_session,(select COUNT(id) from tranning_lesson_usage where `status`=0) as left_session from tranning_lesson as lesson LEFT JOIN tranning_lesson_usage as lesson_usage ON lesson.id=lesson_usage.lesson_id AND lesson_usage.customer_id='" + reqObj.customer_id + "' where lesson.app_id='" + reqObj.app_id + "' AND lesson.lesson_date='" + reqObj.date + "' ORDER BY lesson.id DESC", function(err, result) {
                            if (!!err) {
                                console.error('SQL error: ', err);
                                return next(err);
                            }
                            if (result == '') {

                                res.json({
                                    "status": 'true',
                                    "message": 'no data found',
                                    "response": result
                                });

                            } else {

                                res.json({
                                    "status": 'true',
                                    "message": "data found",
                                    "response": result
                                });
                            }

                        });
                    }

                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});


//Get Lessons Images

router.post('/getLessonsImages', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.lesson_id == '' || reqObj.lesson_id == 0) {
        res.json({
            "status": "error",
            "message": "lesson_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.lesson_id == undefined) {
        res.json({
            "status": "error",
            "message": "lesson_id is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("select * from `tranning_lesson_images` where `app_id`='" + reqObj.app_id + "' AND  `lesson_id`='" + reqObj.lesson_id + "' ORDER BY `id` ASC", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false'
                            });

                        } else {
                            res.json({
                                "status": 'true',
                                "response": result
                            });


                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});


//Lesson book

router.post('/lessonBook', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);

    if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.customer_id == '' || reqObj.customer_id == 0) {
        res.json({
            "status": "error",
            "message": "customer_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.customer_id == undefined) {
        res.json({
            "status": "error",
            "message": "customer_id is required field"
        });
        return false;
    } else if (reqObj.lesson_id == '' || reqObj.lesson_id == 0) {
        res.json({
            "status": "error",
            "message": "lesson_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.lesson_id == undefined) {
        res.json({
            "status": "error",
            "message": "lesson_id is required field"
        });
        return false;
    } else {
        var book_date_time = moment.tz(new Date(), "Europe/Moscow").format("YYYY-MM-DD HH:mm:ss");
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {
                    var query = conn.query("insert into `tranning_lesson_usage` (lesson_id,customer_id,app_id,status,book_date_time) values('" + reqObj.lesson_id + "','" + reqObj.customer_id + "','" + reqObj.app_id + "','0','" + book_date_time + "')", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false'
                            });

                        } else {
                            var query = conn.query("update `tranning_lesson` set `lesson_seats`=lesson_seats-1 where `id`='" + reqObj.lesson_id + "'", function(err, result) {
                                if (!!err) {
                                    console.error('SQL error: ', err);
                                    return next(err);
                                }
                                if (result == '') {

                                    res.json({
                                        "status": 'false'
                                    });

                                } else {
                                    res.json({
                                        "status": 'true'
                                    });


                                }

                            });

                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});

//Lesson Cancel

router.post('/lessonCancel', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);

    if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.customer_id == '' || reqObj.customer_id == 0) {
        res.json({
            "status": "error",
            "message": "customer_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.customer_id == undefined) {
        res.json({
            "status": "error",
            "message": "customer_id is required field"
        });
        return false;
    } else if (reqObj.lesson_id == '' || reqObj.lesson_id == 0) {
        res.json({
            "status": "error",
            "message": "lesson_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.lesson_id == undefined) {
        res.json({
            "status": "error",
            "message": "lesson_id is required field"
        });
        return false;
    } else {
        var book_date_time = moment.tz(new Date(), "Europe/Moscow").format("YYYY-MM-DD HH:mm:ss");
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {
                    var query = conn.query("delete from `tranning_lesson_usage` where `customer_id`='" + reqObj.customer_id + "'  AND `app_id`='" + reqObj.app_id + "'  AND `lesson_id`='" + reqObj.lesson_id + "'", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false'
                            });

                        } else {
                            var query = conn.query("update `tranning_lesson` set `lesson_seats`=lesson_seats+1 where `id`='" + reqObj.lesson_id + "'", function(err, result) {
                                if (!!err) {
                                    console.error('SQL error: ', err);
                                    return next(err);
                                }
                                if (result == '') {

                                    res.json({
                                        "status": 'false'
                                    });

                                } else {
                                    res.json({
                                        "status": 'true'
                                    });


                                }

                            });

                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});

//Delete lesson

router.post('/deleteLesson', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
    if (reqObj.manager_id == '' || reqObj.manager_id == 0) {
        res.json({
            "status": "error",
            "message": "manager_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.manager_id == undefined) {
        res.json({
            "status": "error",
            "message": "manager_id is required field"
        });
        return false;
    } else if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.lesson_id == '' || reqObj.lesson_id == 0) {
        res.json({
            "status": "error",
            "message": "lesson_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.lesson_id == undefined) {
        res.json({
            "status": "error",
            "message": "lesson_id is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("DELETE from `tranning_lesson` where `app_id`='" + reqObj.app_id + "' AND `id`='" + reqObj.lesson_id + "' AND `manager_id`='" + reqObj.manager_id + "'", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'false'
                            });

                        } else {
                            var query = conn.query("DELETE from `tranning_lesson_images` where `lesson_id`='" + reqObj.lesson_id + "'", function(err, result) {
                                if (!!err) {
                                    console.error('SQL error: ', err);
                                    return next(err);
                                }
                                if (result == '') {

                                    res.json({
                                        "status": 'false'
                                    });

                                } else {
                                    res.json({
                                        "status": 'true'
                                    });
                                }

                            });
                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});


//Contact Us edit

router.post('/ContactUsEdit', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);

    if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.manager_id == '' || reqObj.manager_id == 0) {
        res.json({
            "status": "error",
            "message": "manager_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.manager_id == undefined) {
        res.json({
            "status": "error",
            "message": "manager_id is required field"
        });
        return false;
    } else if (reqObj.address == '') {
        res.json({
            "status": "error",
            "message": "address should not be blank"
        });
        return false;
    } else if (reqObj.address == undefined) {
        res.json({
            "status": "error",
            "message": "address is required field"
        });
        return false;
    } else if (reqObj.email == '') {
        res.json({
            "status": "error",
            "message": "email should not be blank"
        });
        return false;
    } else if (reqObj.email == undefined) {
        res.json({
            "status": "error",
            "message": "email is required field"
        });
        return false;
    } else if (reqObj.phone == '') {
        res.json({
            "status": "error",
            "message": "phone should not be blank"
        });
        return false;
    } else if (reqObj.phone == undefined) {
        res.json({
            "status": "error",
            "message": "phone is required field"
        });
        return false;
    } else if (reqObj.lat == '') {
        res.json({
            "status": "error",
            "message": "lat should not be blank"
        });
        return false;
    } else if (reqObj.lat == undefined) {
        res.json({
            "status": "error",
            "message": "lat is required field"
        });
        return false;
    } else if (reqObj.long == '') {
        res.json({
            "status": "error",
            "message": "long should not be blank"
        });
        return false;
    } else if (reqObj.long == undefined) {
        res.json({
            "status": "error",
            "message": "long is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("UPDATE contact_us set `address`='" + reqObj.address + "',`email`='" + reqObj.email + "',`phone`='" + reqObj.phone + "',`lat`='" + reqObj.lat + "',`long`='" + reqObj.long + "' where `app_id`='" + reqObj.app_id + "' AND `manager_id`='" + reqObj.manager_id + "'", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'true',
                                "message": "not update"
                            });

                        } else {

                            res.json({
                                "status": 'true',
                                "message": "update"
                            });
                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});


//Contact Us Get

router.post('/ContactUsGet', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);

    if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("select * from contact_us  where `app_id`='" + reqObj.app_id + "'", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'true',
                                "message": 'no data found',
                                "response": result
                            });

                        } else {

                            res.json({
                                "status": 'true',
                                "message": "data found",
                                "response": result
                            });
                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});


//Lesson user List

router.post('/lessonUserList', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);

    if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.lesson_id == '' || reqObj.lesson_id == 0) {
        res.json({
            "status": "error",
            "message": "lesson_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.lesson_id == undefined) {
        res.json({
            "status": "error",
            "message": "lesson_id is required field"
        });
        return false;
    } else {
        try {

            req.getConnection(function(err, conn) {
                if (!!err) {
                    console.error('SQL Connection error: ', err);
                    return next(err);
                } else {

                    var query = conn.query("Select user.name,lesson.customer_id FROM userinfo as user,tranning_lesson_usage as lesson where user.id = lesson.customer_id and lesson_id='" + reqObj.lesson_id + "' and lesson.app_id='" + reqObj.app_id + "'", function(err, result) {
                        if (!!err) {
                            console.error('SQL error: ', err);
                            return next(err);
                        }
                        if (result == '') {

                            res.json({
                                "status": 'true',
                                "message": 'no data found',
                                "response": result
                            });

                        } else {

                            res.json({
                                "status": 'true',
                                "message": "data found",
                                "response": result
                            });
                        }

                    });
                }

            });
        } catch (ex) {
            console.error("Internal error:" + ex);
            return next(ex);
        }
    }
});


//Coupons 

//create Coupons

router.post('/addCoupon', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
     if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    } else if (reqObj.manager_id == '' || reqObj.manager_id == 0) {
        res.json({
            "status": "error",
            "message": "manager_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.manager_id == undefined) {
        res.json({
            "status": "error",
            "message": "manager_id is required field"
        });
        return false;
    } else if (reqObj.coupon_name == '') {
        res.json({
            "status": "error",
            "message": "coupon_name should not be blank"
        });
        return false;
    } else if (reqObj.coupon_name == undefined) {
        res.json({
            "status": "error",
            "message": "coupon_name is required field"
        });
        return false;
    } else if (reqObj.coupon_code == '') {
        res.json({
            "status": "error",
            "message": "coupon_code should not be blank"
        });
        return false;
    } else if (reqObj.coupon_code == undefined) {
        res.json({
            "status": "error",
            "message": "coupon_code is required field"
        });
        return false;
    } else if (reqObj.coupon_discount == '') {
        res.json({
            "status": "error",
            "message": "coupon_discount should not be blank"
        });
        return false;
    } else if (reqObj.coupon_discount == undefined) {
        res.json({
            "status": "error",
            "message": "coupon_discount is required field"
        });
        return false;
    } else if (reqObj.coupon_exp == '') {
        res.json({
            "status": "error",
            "message": "coupon_exp should not be blank"
        });
        return false;
    } else if (reqObj.coupon_exp == undefined) {
        res.json({
            "status": "error",
            "message": "coupon_exp is required field"
        });
        return false;
    } else{
    try {

        req.getConnection(function(err, conn) {
            if (!!err) {
                console.error('SQL Connection error: ', err);
                return next(err);
            } else {

                var query = conn.query("insert into `coupon` (`coupon_name`,`coupon_code`,`coupon_desc`,`coupon_discount`,`coupon_exp`,`manager_id`,`app_id`) values('" + reqObj.coupon_name + "','" + reqObj.coupon_code + "','" + reqObj.coupon_desc + "','" + reqObj.coupon_discount + "','" + reqObj.coupon_exp + "','" + reqObj.manager_id + "','" + reqObj.app_id + "')", function(err, result) {
                    if (!!err) {
                        console.error('SQL error: ', err);
                        return next(err);
                    }
                    if (result == '') {

                        res.json({
                            "status": 'false',
                            "msg": 'Not create Trainer'
                        });

                    } else {
                        var lastInsertID = result.insertId;
                        // var timestampLength = (JSON.parse(reqObj.timestamp)).length;
                        // var timestamp = JSON.parse(reqObj.timestamp);
                        var timestampLength = (reqObj.timestamp).length;
                        var timestamp = reqObj.timestamp;
                        for (var i = 0; i < timestampLength; i++) {
                            var query = conn.query("update `coupon_images` set `coupon_id`='" + lastInsertID + "',`status`=1 where `timestamp`='" + timestamp[i].timestampId + "' AND `app_id`='" + reqObj.app_id + "' AND `manager_id`='" + reqObj.manager_id + "'", function(err, result) {
                                if (!!err) {
                                    console.error('SQL error: ', err);
                                    return next(err);
                                }

                            });
                        }
                        res.json({
                            "status": 'true'
                        });
                    }

                });
            }

        });
    } catch (ex) {
        console.error("Internal error:" + ex);
        return next(ex);
    }
}
});

//get coupon

router.post('/getCoupon', function(req, res, next) {
    var reqObj = req.body;
    console.log(reqObj);
     if (reqObj.app_id == '' || reqObj.app_id == 0) {
        res.json({
            "status": "error",
            "message": "app_id should not be blank or 0"
        });
        return false;
    } else if (reqObj.app_id == undefined) {
        res.json({
            "status": "error",
            "message": "app_id is required field"
        });
        return false;
    }else{
    try {

        req.getConnection(function(err, conn) {
            if (!!err) {
                console.error('SQL Connection error: ', err);
                return next(err);
            } else {

                var query = conn.query("SELECT * FROM (SELECT a.coupon_id,a.id,a.image, b.coupon_name, b.coupon_code, b.coupon_desc,b.coupon_discount,b.coupon_exp, b.manager_id, b.app_id FROM coupon_images as a,coupon as b where a.coupon_id = b.id and b.app_id = a.app_id and b.app_id ='" + reqObj.app_id + "' ORDER BY a.id DESC) AS t GROUP BY coupon_id", function(err, result) {
                    if (!!err) {
                        console.error('SQL error: ', err);
                        return next(err);
                    }
                    if (result == '') {

                        res.json({
                            "status": 'true',
                            "message":"no data found",
                            "response": result
                        });

                    } else {
                        res.json({
                            "status": 'true',
                            "response": result
                        });


                    }

                });
            }

        });
    } catch (ex) {
        console.error("Internal error:" + ex);
        return next(ex);
    }
}
});
