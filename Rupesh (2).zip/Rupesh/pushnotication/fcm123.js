    var gcm = require('node-gcm');
    var moment = require('moment-timezone');
    var apn = require("apn");
    //Android server keys
    var sender = new gcm.Sender('AIzaSyBk7spwgAT8amwdwPWRAqBqTFxGyMIisPM'); // customer server key
    var sender1 = new gcm.Sender('AIzaSyBrf4xZKPDRmZmQsCJLDNFUoiyb2rH47rQ'); //manager server key
    var sender2 = new gcm.Sender('AIzaSyBjy0c6I-eOGkotFuDtZFLkvavuscvrp30'); //manager server key
    var sender3 = new gcm.Sender('AIzaSyB2jXTp6KcmovT-sfKZ2rMRNa8xE86VBsQ'); //manager server key
    var sender4 = new gcm.Sender('AIzaSyDT3twg2MRguktOAUi9ET_h-FH1DjpjqQI'); //manager server key
    var sender5 = new gcm.Sender('AIzaSyDJLuox8AJTgwCgcnUQnM_DvKJ0o7dxj3Y'); //manager server key

    //IOS Pem files
    var serviceIOS = new apn.Provider({
        cert: "./resources/ApplePushFitness.pem",
        key: "./resources/ApplePushFitness.pem",
        production: true
    }); //Fitness App Cutomer pem 
    //IOS Pem files
    var serviceIOSMan = new apn.Provider({
        cert: "./resources/ManagerApplePush.pem",
        key: "./resources/ManagerApplePush.pem",
        production: true
    }); //Fitness App manager pem 
	
	var serviceBizz = new apn.Provider({
        cert: "./resources/BizzApp6Dis.pem",
        key: "./resources/BizzApp6Dis.pem",
        production: true
    }); //Bizz App customer pem
   
    var serviceBizz = new apn.Provider({
        cert: "./resources/BizzApp6Dis.pem",
        key: "./resources/BizzApp6Dis.pem",
        production: true
    }); //Bizz App customer pem   
    //var serverKey = 'AIzaSyBk7spwgAT8amwdwPWRAqBqTFxGyMIisPM'; //put your server key here 
    //var fcm = new FCM(serverKey);
    var fcmPushnotification = {};
    var mysql1 = require('mysql');
    var connection1 = mysql1.createConnection({
        host: 'localhost',
        user: 'root',
        password: 'mindcrew01',
        database: 'fitnessapp'
    });
    fcmPushnotification.fcmPushnotificationFunction = function(notification_type, dataResult, message1, user_type) {
        switch (notification_type) {
            case "1_lesson_left":
                try {
                    //connection1.connect();
                    connection1.connect(function(err) {
                        if (err) {
                            console.error('Error:- ' + err.stack);
                            return;
                        }

                        console.log('Connected Id:- ' + connection1.threadId);
                    });
                    connection1.query("SELECT a.*,b.name,a.device_type from user_registration_token as a,userinfo as b where a.user_id=b.id and (a.`user_type`='customer' OR a.`user_type`='normal') AND b.lesson_no=1 AND a.app_id=1 GROUP BY a.id", function(error, results, fields) {
                        if (error) throw error;
                        if (results == '') {

                        } else {
                            var dataResult = results;
                            //var dataResult=JSON.parse(dataResult);
                            for (x in dataResult) {
                                if (dataResult[x].device_type == 'android') {
                                    console.log('1_lesson_left');
                                    var deviceToken = dataResult[x].registration_token;
                                    var message = new gcm.Message({
                                        // One lesson left in your card
                                        // Hello ' + dataResult[x].name + ', you left only one lesson in your training card

                                        notification: {
                                            title: 'נשאר אימון אחד בכרטיסיית האימונים שלך',
                                            body: 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים'
                                        }
                                    });
                                    message.addData('message', 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים');
                                    message.addData('type', "1_lesson_left");
                                    message.addData('appname', "fitnessApp");
                                    message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
                                    var regTokens = [deviceToken];
                                    sender.send(message, {
                                        registrationTokens: regTokens
                                    }, function(err, response) {
                                        if (err) console.error(err);
                                        else console.log(response);
                                    });
                                } else if (dataResult[x].device_type == 'ios') {
                                    var deviceToken = dataResult[x].registration_token;
                                    var tokens = [deviceToken];

                                    var note = new apn.Notification({
                                        alert: 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים'
                                    });
                                    var data1 = {};
                                    data1.type = "1_lesson_left";
                                    data1.data = 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים';
                                    note.payload = data1;
                                    // The topic is usually the bundle identifier of your application.
                                    note.topic = "com.bizz.fitnessapp";
                                    note.type = "1_lesson_left";
                                    serviceIOS.send(note, tokens).then(result => {
                                        console.log("sent:", result.sent.length);
                                        console.log("failed:", result.failed.length);
                                        console.log(result.failed);
                                    });
                                    // For one-shot notification tasks you may wish to shutdown the connection
                                    // after everything is sent, but only call shutdown if you need your 
                                    // application to terminate.
                                    serviceIOS.shutdown();
                                }
                            }
                        }
                    });
                    connection1.query("SELECT a.*,b.name from user_registration_token as a,userinfo as b where a.user_id=b.id and (a.`user_type`='manager') AND a.app_id=1 GROUP BY a.id", function(error, results, fields) {
                        if (error) throw error;
                            if (results == '') {
                        } else {
                            var dataResult = results;
                            //var dataResult=JSON.parse(dataResult);
                            for (x in dataResult) {
                                console.log(dataResult[x].registration_token);
                                console.log('1_lesson_left');
                                var deviceToken = dataResult[x].registration_token;
                                var message = new gcm.Message({
                                    // One lesson left in your card
                                    // Hello ' + dataResult[x].name + ', you left only one lesson in your training card

                                    notification: {
                                        title: 'נשאר אימון אחד בכרטיסיית האימונים שלך',
                                        //body: 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים'
										body: 'sourabh נותר אימון 1'
										
                                    }
                                });
                                message.addData('message', 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים');
                                message.addData('type', "1_lesson_left");
                                message.addData('appname', "fitnessApp");
                                message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
                                var regTokens = [deviceToken];
                                sender1.send(message, {
                                    registrationTokens: regTokens
                                }, function(err, response) {
                                    if (err) console.error(err);
                                    else console.log(response);
                                });
                            }
                        }
                    });


                    // connection1.end();

                } catch (ex) {
                    console.error("Internal error:" + ex);
                    return next(ex);
                }
                break;
            case "1_week_left":
                var dataResult = JSON.parse(dataResult);
                for (x in dataResult) {
                    console.log(dataResult[x].registration_token);
                    if (dataResult[x].device_type == 'android') {
                        var deviceToken = dataResult[x].registration_token;
                        var message = new gcm.Message({
                            notification: {
                                //Your lesson will expire by next week
                                //Hello ' + dataResult[x].name + ', you left only one lesson in your training card
                                title: 'תוקף כרטיסיית האימנוים שלך יפוג בעוד שבוע',
                                body: 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים'
                            }
                        });
                        message.addData('message', 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים');
                        message.addData('type', "1_week_left");
                        message.addData('appname', "fitnessApp");
                        message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
                        var regTokens = [deviceToken];
                        sender.send(message, {
                            registrationTokens: regTokens
                        }, function(err, response) {
                            if (err) console.error(err);
                            else console.log(response);
                        });
                    } else if (dataResult[x].device_type == 'ios') {
                        var deviceToken = dataResult[x].registration_token;
                        var tokens = [deviceToken];

                        var note = new apn.Notification({
                            alert: 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים'
                        });
                        var data1 = {};
                        data1.type = "1_week_left";
                        data1.data = 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים';
                        note.payload = data1;
                        // The topic is usually the bundle identifier of your application.
                        note.topic = "com.bizz.fitnessapp";
                        note.type = "1_week_left";
                        serviceIOS.send(note, tokens).then(result => {
                            console.log("sent:", result.sent.length);
                            console.log("failed:", result.failed.length);
                            console.log(result.failed);
                        });
                        // For one-shot notification tasks you may wish to shutdown the connection
                        // after everything is sent, but only call shutdown if you need your 
                        // application to terminate.
                        serviceIOS.shutdown();
                    }
                }
                break;
            case "lesson_booked_by_customer":
                try {
                    //connection1.connect();
                    connection1.connect(function(err) {
                        if (err) {
                            console.error('Error:- ' + err.stack);
                            return;
                        }

                        console.log('Connected Id:- ' + connection1.threadId);
                    });
                    connection1.query("SELECT a.*,b.name from user_registration_token as a,userinfo as b where a.user_id=b.id and a.`user_type`='manager' and a.app_id=1 GROUP BY a.id", function(error, results, fields) {
                        if (error) throw error;
                        if (results == '') {

                        } else {
                            var dataResult = results;
                            //var dataResult=JSON.parse(dataResult);
                            for (x in dataResult) {
                                if (dataResult[x].device_type == 'android') {
                                    console.log(dataResult[x].registration_token);
                                    var deviceToken = dataResult[x].registration_token;
                                    var message = new gcm.Message({
                                        //Lesson is booked by customer
                                        //Hello ' + dataResult[x].name + ', lesson has booked by customer
                                        notification: {
                                            title: 'השיעור הוזמן על ידי הלקוח',
                                            body: 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח' + message1
                                        }
                                    });
                                    message.addData('message', 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח ' + message1);
                                    message.addData('type', "lesson_booked_by_customer");
                                    message.addData('appname', "fitnessApp");
                                    message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
                                    var regTokens = [deviceToken];
                                    sender1.send(message, {
                                        registrationTokens: regTokens
                                    }, function(err, response) {
                                        if (err) console.error(err);
                                        else console.log(response);
                                    });
                                } else if (dataResult[x].device_type == 'ios') {
                                    var deviceToken = dataResult[x].registration_token;
                                    var tokens = [deviceToken];

                                    var note = new apn.Notification({
                                        alert: 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח ' + message1
                                    });
                                    var data1 = {};
                                    data1.type = "lesson_booked_by_customer";
                                    data1.data = 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח ' + message1;
                                    note.payload = data1;
                                    // The topic is usually the bundle identifier of your application.
                                    note.topic = "com.bizz.fitnessManager";
                                    note.type = "lesson_booked_by_customer";
                                    serviceIOSMan.send(note, tokens).then(result => {
                                        console.log("sent:", result.sent.length);
                                        console.log("failed:", result.failed.length);
                                        console.log(result.failed);
                                    });
                                    // For one-shot notification tasks you may wish to shutdown the connection
                                    // after everything is sent, but only call shutdown if you need your 
                                    // application to terminate.
                                    serviceIOSMan.shutdown();
                                }
                            }
                        }
                    });

                    // connection1.end();

                } catch (ex) {
                    console.error("Internal error:" + ex);
                    return next(ex);
                }
                break;
            case "lesson_cancel_by_customer":
                try {
                    //connection1.connect();
                    connection1.connect(function(err) {
                        if (err) {
                            console.error('Error:- ' + err.stack);
                            return;
                        }

                        console.log('Connected Id:- ' + connection1.threadId);
                    });
                    connection1.query("SELECT a.*,b.name from user_registration_token as a,userinfo as b where a.user_id=b.id and a.`user_type`='manager' and a.app_id=1 GROUP BY a.id", function(error, results, fields) {
                        if (error) throw error;
                        if (results == '') {

                        } else {
                            var dataResult = results;
                            //var dataResult=JSON.parse(dataResult);
                            for (x in dataResult) {
                                if (dataResult[x].device_type == 'android') {
                                    console.log(dataResult[x].registration_token);
                                    var deviceToken = dataResult[x].registration_token;
                                    var message = new gcm.Message({
                                        notification: {
                                            //Lesson cancel by customer
                                            //Hello ' + dataResult[x].name + ', lesson has been cancel by customer
                                            title: 'השיעור בוטל על ידי הלקוח',
                                            body: 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1
                                        }
                                    });
                                    message.addData('message', 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1);
                                    message.addData('type', "lesson_cancel_by_customer");
                                    message.addData('appname', "fitnessApp");
                                    message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
                                    var regTokens = [deviceToken];
                                    sender1.send(message, {
                                        registrationTokens: regTokens
                                    }, function(err, response) {
                                        if (err) console.error(err);
                                        else console.log(response);
                                    });
                                } else if (dataResult[x].device_type == 'ios') {
                                    var deviceToken = dataResult[x].registration_token;
                                    var tokens = [deviceToken];

                                    var note = new apn.Notification({
                                        alert: 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1
                                    });
                                    var data1 = {};
                                    data1.type = "lesson_cancel_by_customer";
                                    data1.data = 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1;
                                    note.payload = data1;
                                    // The topic is usually the bundle identifier of your application.
                                    note.topic = "com.bizz.fitnessManager";
                                    note.type = "lesson_cancel_by_customer";
                                    serviceIOSMan.send(note, tokens).then(result => {
                                        console.log("sent:", result.sent.length);
                                        console.log("failed:", result.failed.length);
                                        console.log(result.failed);
                                    });
                                    // For one-shot notification tasks you may wish to shutdown the connection
                                    // after everything is sent, but only call shutdown if you need your 
                                    // application to terminate.
                                    serviceIOSMan.shutdown();
                                }
                            }
                        }
                    });

                    // connection1.end();

                } catch (ex) {
                    console.error("Internal error:" + ex);
                    return next(ex);
                }
                break;

            case "new_msg_from_manager":
                try {
                    //connection1.connect();
                    connection1.connect(function(err) {
                        if (err) {
                            console.error('Error:- ' + err.stack);
                            return;
                        }

                        console.log('Connected Id:- ' + connection1.threadId);
                    });
                    connection1.query("SELECT a.*,b.name from user_registration_token as a,userinfo as b where a.user_id=b.id and a.`user_type`='customer' and a.app_id=1 GROUP BY a.id", function(error, results, fields) {
                        if (error) throw error;
                        if (results == '') {

                        } else {
                            var dataResult = results;
                            //var dataResult=JSON.parse(dataResult);
                            for (x in dataResult) {
                                if (dataResult[x].device_type == 'android') {
                                    console.log(dataResult[x].registration_token);
                                    var deviceToken = dataResult[x].registration_token;
                                    var message = new gcm.Message({
                                        // New message from manager
                                        //Hello ' + dataResult[x].name + ', you have new message from manage
                                        notification: {
                                            title: 'הודעה חדשה ממיכל ממן',
                                            body: 'שלום , ' + dataResult[x].name + ' , יש לך הודעה חדשה ממיכל ממן'
                                        }
                                    });
                                    message.addData('message', 'שלום , ' + dataResult[x].name + ' , יש לך הודעה חדשה ממיכל ממן');
                                    message.addData('type', "new_msg_from_manager");
                                    message.addData('appname', "fitnessApp");
                                    message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
                                    var regTokens = [deviceToken];
                                    sender.send(message, {
                                        registrationTokens: regTokens
                                    }, function(err, response) {
                                        if (err) console.error(err);
                                        else console.log(response);
                                    });
                                } else if (dataResult[x].device_type == 'ios') {
                                    var deviceToken = dataResult[x].registration_token;
                                    var tokens = [deviceToken];

                                    var note = new apn.Notification({
                                        alert: 'שלום , ' + dataResult[x].name + ' , יש לך הודעה חדשה ממיכל ממן'
                                    });
                                    var data1 = {};
                                    data1.type = "new_msg_from_manager";
                                    data1.data = 'שלום , ' + dataResult[x].name + ' , יש לך הודעה חדשה ממיכל ממן';
                                    note.payload = data1;
                                    // The topic is usually the bundle identifier of your application.
                                    note.topic = "com.bizz.fitnessManager";
                                    note.type = "new_msg_from_manager";
                                    serviceIOSMan.send(note, tokens).then(result => {
                                        console.log("sent:", result.sent.length);
                                        console.log("failed:", result.failed.length);
                                        console.log(result.failed);
                                    });
                                    // For one-shot notification tasks you may wish to shutdown the connection
                                    // after everything is sent, but only call shutdown if you need your 
                                    // application to terminate.
                                    serviceIOSMan.shutdown();
                                }
                            }
                        }
                    });

                    // connection1.end();

                } catch (ex) {
                    console.error("Internal error:" + ex);
                    return next(ex);
                }
                break;
            case "1_hours_before_lesson":
				console.log("pp sdfs f dfsf sdf dfsf");
                var dataResult = JSON.parse(dataResult);
                for (x in dataResult) {
                    
                        var lesson_serverDateTime = moment.tz(new Date(), "Europe/Kiev").format("YYYY-MM-DD HH:mm:ss");
                        var lesson_serverDateTime1 = moment.tz(new Date(), "Europe/Kiev").format();
                        // console.log(lesson_serverDateTime+ "server time");
                        var diff = Math.abs(new Date(dataResult[x].lesson_serverDateTime) - new Date(lesson_serverDateTime));
                        var minutes = Math.floor((diff / 1000) / 60);
                        //console.log(minutes +'-'+ dataResult[x].lesson_id);
                        if (dataResult[x].lesson_serverDateTime > new Date(lesson_serverDateTime)) {
                            console.log("Got it");
                        }
						//console.log(dataResult[x].lesson_name+'-->'+dataResult[x].lesson_serverDateTime+'-->'+ new Date(lesson_serverDateTime) + '---->' + dataResult[x].one_hour_before);
						console.log(minutes);
		 if (minutes==60 && (dataResult[x].lesson_serverDateTime > new Date(lesson_serverDateTime)) && dataResult[x].one_hour_before==0) {
		//if (minutes==186) {
			console.log("pranjal pathak");

                            if (dataResult[x].device_type == 'android') {
                            var deviceToken = dataResult[x].registration_token;
                            //console.log(deviceToken);
                            var message = new gcm.Message({
                                //you have a lesson in a hour
                                //Hello ' + dataResult[x].name + ', you have a lesson in a hour
                                notification: {
                                    title: 'תזכורת להתחלת שיעור בעוד שעה',
                                    body: 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה'
                                }
                            });
                            message.addData('message', 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה');
                            message.addData('type', "1_hours_before_lesson");
                            message.addData('appname', "fitnessApp");
                            message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
                            var regTokens = [deviceToken];
                            sender.send(message, {
                                registrationTokens: regTokens
                            }, function(err, response) {
                                if (err) console.error(err);
                                else console.log(response);
							});
							console.log("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = "+dataResult[x].customer_id+" AND lesson_id = "+dataResult[x].lesson_id+"");
							connection1.query("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = "+dataResult[x].customer_id+" AND lesson_id = "+dataResult[x].lesson_id+"", function(error, results, fields) {
									if(error){
										console.log(err);
									}
									
								});
                        } else if (dataResult[x].device_type == 'ios') {
                        var deviceToken = dataResult[x].registration_token;
                        var tokens = [deviceToken];

                        var note = new apn.Notification({
                            alert: 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה'
                        });
                        var data1 = {};
                        data1.type = "1_hours_before_lesson";
                        data1.data = 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה';
                        note.payload = data1;
                        // The topic is usually the bundle identifier of your application.
                        note.topic = "com.bizz.fitnessapp";
                        note.type = "1_hours_before_lesson";
                        serviceIOS.send(note, tokens).then(result => {
                            console.log("sent:", result.sent.length);
                            console.log("failed:", result.failed.length);
                            console.log(result.failed);
							
							
                        });
                        // For one-shot notification tasks you may wish to shutdown the connection
                        // after everything is sent, but only call shutdown if you need your 
                        // application to terminate.
						connection1.query("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = "+dataResult[x].customer_id+" AND lesson_id = "+dataResult[x].lesson_id+"", function(error, results, fields) {
									if(error){
										console.log(err);
									}
									
								});
                        serviceIOS.shutdown();
                    }
                        } 
                    
                }
                break;
            case "Not_assign_user_lesson":

                var dataResult = JSON.parse(dataResult);
                for (x in dataResult) {
                    if (dataResult[x].device_type == 'android') {
                        var deviceToken = dataResult[x].registration_token;
                        var message = new gcm.Message({
                            //You didn’t assign to training lesson for the next week
                            //Hello ' + dataResult[x].name + ', you didn’t assign to training lesson for the next week
                            notification: {
                                title: 'לא נרשמת לאימונים בשבוע הבא',
                                body: 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא '
                            }
                        });
                        message.addData('message', 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא');
                        message.addData('type', "Not_assign_user_lesson");
                        message.addData('appname', "fitnessApp");
                        message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
                        var regTokens = [deviceToken];
                        sender.send(message, {
                            registrationTokens: regTokens
                        }, function(err, response) {
                            if (err) console.error(err);
                            else console.log(response);
                            moment
                        });
                    } else if (dataResult[x].device_type == 'ios') {
                        var deviceToken = dataResult[x].registration_token;
                        var tokens = [deviceToken];

                        var note = new apn.Notification({
                            alert: 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא'
                        });
                        var data1 = {};
                        data1.type = "Not_assign_user_lesson";
                        data1.data = 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא';
                        note.payload = data1;
                        // The topic is usually the bundle identifier of your application.
                        note.topic = "com.bizz.fitnessapp";
                        note.type = "Not_assign_user_lesson";
                        serviceIOS.send(note, tokens).then(result => {
                            console.log("sent:", result.sent.length);
                            console.log("failed:", result.failed.length);
                            console.log(result.failed);
                        });
                        // For one-shot notification tasks you may wish to shutdown the connection
                        // after everything is sent, but only call shutdown if you need your 
                        // application to terminate.
                        serviceIOS.shutdown();
                    }
                }
                break;
            case "send_Push_Message_ToAll":
                try {
                    //connection1.connect();
                    connection1.connect(function(err) {
                        if (err) {
                            console.error('Error:- ' + err.stack);
                            return;
                        }

                        console.log('Connected Id:- ' + connection1.threadId);
                    });
                    if (user_type == 'all') {
                        var queryStr = "SELECT a.* from user_registration_token as a where a.`user_type`='customer' OR a.`user_type`='normal' and a.app_id=1 GROUP BY a.user_id";
                    } else {
                        var queryStr = "SELECT a.* from user_registration_token as a where a.`user_type`='customer' and a.app_id=1 GROUP BY a.user_id";
                    }
                    connection1.query(queryStr, function(error, results, fields) {
                        if (error) throw error;
                        if (results == '') {

                        } else {
                            var dataResult = results;
                            //var dataResult=JSON.parse(dataResult);
                            for (x in dataResult) {
                                if (dataResult[x].device_type == 'android') {
                                    console.log(dataResult[x].registration_token);
                                    var deviceToken = dataResult[x].registration_token;
                                    var message = new gcm.Message({
                                        //You have a message from manager
                                        notification: {
                                            title: 'הודעה חדשה ממיכל ממן',
                                            body: message1
                                        }
                                    });
                                    message.addData('message', message1);
                                    message.addData('type', "send_Push_Message_ToAll");
                                    message.addData('appname', "fitnessApp");
                                    message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
                                    var regTokens = [deviceToken];
                                    sender.send(message, {
                                        registrationTokens: regTokens
                                    }, function(err, response) {
                                        if (err) console.error(err);
                                        else console.log(response);
                                    });
                                } else if (dataResult[x].device_type == 'ios') {
                                    var deviceToken = dataResult[x].registration_token;
                                    var tokens = [deviceToken];

                                    var note = new apn.Notification({
                                        alert: message1
                                    });
                                    var data1 = {};
                                    data1.type = "send_Push_Message_ToAll";
                                    data1.data = message1;
                                    note.payload = data1;
                                    // The topic is usually the bundle identifier of your application.
                                    note.topic = "com.bizz.fitnessapp";
                                    note.type = "send_Push_Message_ToAll";
                                    serviceIOS.send(note, tokens).then(result => {
                                        console.log("sent:", result.sent.length);
                                        console.log("failed:", result.failed.length);
                                        console.log(result.failed);
                                    });
                                    // For one-shot notification tasks you may wish to shutdown the connection
                                    // after everything is sent, but only call shutdown if you need your 
                                    // application to terminate.
                                    serviceIOS.shutdown();
                                }
                            }
                        }
                    });

                    // connection1.end();

                } catch (ex) {
                    console.error("Internal error:" + ex);
                    return next(ex);
                }
                break;

            case "send_Push_Message_ToAll_bizzapp6":
                try {
                    //connection1.connect();
                    connection1.connect(function(err) {
                        if (err) {
                            console.error('Error:- ' + err.stack);
                            return;
                        }

                        console.log('Connected Id:- ' + connection1.threadId);
                    });
                    var queryStr = "SELECT a.* from user_registration_token as a where a.`user_id`=0 AND a.app_id='" + user_type + "'";
                    connection1.query(queryStr, function(error, results, fields) {
                        if (error) throw error;
                        if (results == '') {

                        } else {
                            var dataResult = results;
                            //var dataResult=JSON.parse(dataResult);
                            for (x in dataResult) {
								if (dataResult[x].device_type == 'android') {
                                console.log(dataResult[x].registration_token);
                                var deviceToken = dataResult[x].registration_token;
                                var message = new gcm.Message({
                                    //You have a message from manager
                                    notification: {
                                        title: 'ג חיון',
                                        body: message1
                                    }
                                });
                                message.addData('message', message1);
                                message.addData('type', "send_Push_Message_ToAll_bizzapp6");
                                message.addData('appname', "bizzapp6");
                                message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
                                var regTokens = [deviceToken];
                                sender2.send(message, {
                                    registrationTokens: regTokens
                                }, function(err, response) {
                                    if (err) console.error(err);
                                    else console.log(response);
                                });
								} else if (dataResult[x].device_type == 'ios') {
                                    var deviceToken = dataResult[x].registration_token;
                                    var tokens = [deviceToken];

                                    var note = new apn.Notification({
                                        alert: message1
                                    });
                                    var data1 = {};
                                    data1.type = "send_Push_Message_ToAll_bizzapp6";
                                    data1.data = message1;
                                    note.payload = data1;
                                    // The topic is usually the bundle identifier of your application.
                                    note.topic = "com.Bizz.G.HAUN";
                                    note.type = "send_Push_Message_ToAll_bizzapp6";
                                    serviceBizz.send(note, tokens).then(result => {
                                        console.log("sent:", result.sent.length);
                                        console.log("failed:", result.failed.length);
                                        console.log(result.failed);
                                    });
                                    // For one-shot notification tasks you may wish to shutdown the connection
                                    // after everything is sent, but only call shutdown if you need your 
                                    // application to terminate.
                                    serviceBizz.shutdown();
                                }
                            }
                        }
                    });

                    // connection1.end();

                } catch (ex) {
                    console.error("Internal error:" + ex);
                    return next(ex);
                }
                break;

            case "send_Push_Message_ToAll_poolapp2":
                try {
                    //connection1.connect();
                    connection1.connect(function(err) {
                        if (err) {
                            console.error('Error:- ' + err.stack);
                            return;
                        }

                        console.log('Connected Id:- ' + user_type);
                    });
                    var queryStr = "SELECT a.* from user_registration_token as a where a.`user_id`=0 AND a.app_id='" + user_type + "' GROUP BY a.user_id";
                    connection1.query(queryStr, function(error, results, fields) {
                        if (error) throw error;
                        if (results == '') {

                        } else {
                            var dataResult = results;
                            //var dataResult=JSON.parse(dataResult);
                            for (x in dataResult) {
                                console.log(dataResult[x].registration_token);
                                var deviceToken = dataResult[x].registration_token;
                                var message = new gcm.Message({
                                    //You have a message from manager
                                    notification: {
                                        title: 'ספלאש בריכות שחייה',
                                        body: message1
                                    }
                                });
                                message.addData('message', message1);
                                message.addData('type', "send_Push_Message_ToAll_poolapp2");
                                message.addData('appname', "poolapp2");
                                message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
                                var regTokens = [deviceToken];
                                sender3.send(message, {
                                    registrationTokens: regTokens
                                }, function(err, response) {
                                    if (err) console.error(err);
                                    else console.log(response);
                                });
                            }
                        }
                    });

                    // connection1.end();

                } catch (ex) {
                    console.error("Internal error:" + ex);
                    return next(ex);
                }
                break;

            case "send_Push_Message_ToAll_yazivapp":
                try {
                    //connection1.connect();
                    connection1.connect(function(err) {
                        if (err) {
                            console.error('Error:- ' + err.stack);
                            return;
                        }

                        console.log('Connected Id:- ' + user_type);
                    });
                    var queryStr = "SELECT a.* from user_registration_token as a where a.`user_id`=0 AND a.app_id='" + user_type + "' GROUP BY a.user_id";
                    connection1.query(queryStr, function(error, results, fields) {
                        if (error) throw error;
                        if (results == '') {

                        } else {
                            var dataResult = results;
                            //var dataResult=JSON.parse(dataResult);
                            for (x in dataResult) {
                                console.log(dataResult[x].registration_token);
                                var deviceToken = dataResult[x].registration_token;
                                var message = new gcm.Message({
                                    //You have a message from manager
                                    notification: {
                                        title: 'יציב מרכז מזון',
                                        body: message1
                                    }
                                });
                                message.addData('message', message1);
                                message.addData('type', "send_Push_Message_ToAll_yazivapp");
                                message.addData('appname', "yazivapp");
                                message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
                                var regTokens = [deviceToken];
                                sender4.send(message, {
                                    registrationTokens: regTokens
                                }, function(err, response) {
                                    if (err) console.error(err);
                                    else console.log(response);
                                });
                            }
                        }
                    });

                    // connection1.end();

                } catch (ex) {
                    console.error("Internal error:" + ex);
                    return next(ex);
                }
                break;

            case "send_Push_Message_ToAll_babyshick":
                try {
                    //connection1.connect();
                    connection1.connect(function(err) {
                        if (err) {
                            console.error('Error:- ' + err.stack);
                            return;
                        }

                        console.log('Connected Id:- ' + user_type);
                    });
                    var queryStr = "SELECT a.* from user_registration_token as a where a.`user_id`=0 AND a.app_id='" + user_type + "'";
                    connection1.query(queryStr, function(error, results, fields) {
                        if (error) throw error;
                        if (results == '') {

                        } else {
                            var dataResult = results;
                            //var dataResult=JSON.parse(dataResult);
                            for (x in dataResult) {
                                if (dataResult[x].device_type == 'android') {
                                    console.log("babyshick Pushnotication Android " + dataResult[x].registration_token);
                                    var deviceToken = dataResult[x].registration_token;
                                    var message = new gcm.Message({
                                        //You have a message from manager
                                        notification: {
                                            title: 'בייבי שיק',
                                            body: message1
                                        }
                                    });
                                    message.addData('message', message1);
                                    message.addData('type', "send_Push_Message_ToAll_babyshick");
                                    message.addData('appname', "babyshick");
                                    message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
                                    var regTokens = [deviceToken];
                                    sender5.send(message, {
                                        registrationTokens: regTokens
                                    }, function(err, response) {
                                        if (err) console.error(err);
                                        else console.log(response);
                                    });
                                } else if (dataResult[x].device_type == 'ios') {
                                    var deviceToken = dataResult[x].registration_token;
                                    var tokens = [deviceToken];
                                    var serviceIOS5 = new apn.Provider({
                                        cert: "./resources/babyshic.pem",
                                        key: "./resources/babyshic.pem",
                                        production: false
                                    }); //BabyShick App pem 
                                    var note = new apn.Notification({
                                        alert: message1
                                    });
                                    var data1 = {};
                                    data1.type = "send_Push_Message_ToAll_babyshick";
                                    data1.data = message1;
                                    note.payload = data1;
                                    // The topic is usually the bundle identifier of your application.
                                    note.topic = "com.Bizz.babyshickapp";
                                    note.type = "send_Push_Message_ToAll_babyshick";
                                    serviceIOS5.send(note, tokens).then(result => {
                                        console.log("sent:", result.sent.length);
                                        console.log("failed:", result.failed.length);
                                        console.log(result.failed);
                                    });
                                    // For one-shot notification tasks you may wish to shutdown the connection
                                    // after everything is sent, but only call shutdown if you need your 
                                    // application to terminate.
                                    serviceIOS5.shutdown();
                                }
                            }
                        }
                    });

                    // connection1.end();

                } catch (ex) {
                    console.error("Internal error:" + ex);
                    return next(ex);
                }
                break;


            case "send_Push_Message_ToSelectedCustomer":
                try {
                    //connection1.connect();
                    connection1.connect(function(err) {
                        if (err) {
                            console.error('Error:- ' + err.stack);
                            return;
                        }
                        // console.log('Connected Id:- ' + connection1.threadId);
                    });
                    var selected_customer = user_type;
                    var queryStr = "SELECT * FROM `user_registration_token` WHERE `user_id` IN (" + selected_customer + ") GROUP BY user_id";
                    //console.log(queryStr);

                    connection1.query(queryStr, function(error, results, fields) {
                        if (error) throw error;
                        if (results == '') {
                            // console.log('no data');
                        } else {
                            // console.log(results);
                            var dataResult = results;
                            //var dataResult=JSON.parse(dataResult);
                            for (x in dataResult) {
                                //console.log(dataResult[x].user_id);
                                var deviceToken = dataResult[x].registration_token;
                                var message = new gcm.Message({
                                    //You have a message from manager
                                    notification: {
                                        title: 'הודעה חדשה ממיכל ממן',
                                        body: message1
                                    }
                                });
                                message.addData('message', message1);
                                message.addData('type', "send_Push_Message_ToAll");
                                message.addData('appname', "fitnessApp");
                                message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
                                var regTokens = [deviceToken];
                                sender.send(message, {
                                    registrationTokens: regTokens
                                }, function(err, response) {
                                    /*if (err) console.error(err);
                                    else console.log(response);*/
                                });
                            }
                        }
                    });

                    // connection1.end();

                } catch (ex) {
                    console.error("Internal error:" + ex);
                    return next(ex);
                }
                break;
            case "autoNotification":
                //console.log(date_format(new Date(),'%H:%i:%s'));
                var deviceToken = "ba8cd9e147140e377b0ee1859876cfef8b6b8c311cf427dab8382bb70be2f610";
                var tokens = [deviceToken];

                var note = new apn.Notification({
                    alert: "First notification msg"
                });
                var data1 = {};
                data1.type = "Testing notification";
                data1.data = "first Notification data";
                note.payload = data1;
                // The topic is usually the bundle identifier of your application.
                note.topic = "com.bizz.fitnessapp";
                note.type = "Testing notification note";
                serviceIOS.send(note, tokens).then(result => {
                    console.log("sent:", result.sent.length);
                    console.log("failed:", result.failed.length);
                    console.log(result.failed);
                });
                // For one-shot notification tasks you may wish to shutdown the connection
                // after everything is sent, but only call shutdown if you need your 
                // application to terminate.
                serviceIOS.shutdown();

                break;

            default:
                console.log(2);
        }
    }
    //     var message = { //this may vary according to the message type (single recipient, multicast, topic, et cetera) 
    //     to: 'etSpuqk0KYg:APA91bEDMeLkAPgKfQ3Z0_Mt_KWoKiHC0Aatqs2u_1pcaMxEAbVVJOFM-iByG8HSNAG5BU7R2AOyWcvpOujCj7ThH1M-6-4xMzlFIeUYqhrGoch_g9QsK76u0J2I6toIJma-G3kvLLQC', 
    //     collapse_key: 'your_collapse_key',

    //     notification: {
    //         title: 'Manager push notification', 
    //         body: 'Body of your push notification' 
    //     },

    //     data: {  //you can send only notification or only data(or include both) 
    //         my_key: 'my value',
    //         my_another_key: 'my another value'
    //     }
    // };

    // fcm.send(message, function(err, response){
    //     if (err) {
    //         console.log("Something has gone wrong!");
    //     } else {
    //         console.log("Successfully sent with response: ", response);
    //     }
    // });
    module.exports = fcmPushnotification;