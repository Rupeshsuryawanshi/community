//     var gcm = require('node-gcm');
//     var moment = require('moment-timezone');
//     var apn = require("apn");
//     //Android server keys
//     var sender = new gcm.Sender('AIzaSyBk7spwgAT8amwdwPWRAqBqTFxGyMIisPM'); // Fitness app customer server key
//     var sender1 = new gcm.Sender('AIzaSyBrf4xZKPDRmZmQsCJLDNFUoiyb2rH47rQ'); // fitness app manager server key
//     var sender2 = new gcm.Sender('AIzaSyBjy0c6I-eOGkotFuDtZFLkvavuscvrp30'); //bizzapp6 server key
//     var sender3 = new gcm.Sender('AIzaSyB2jXTp6KcmovT-sfKZ2rMRNa8xE86VBsQ'); //poolapp2 server key
//     var sender4 = new gcm.Sender('AIzaSyDT3twg2MRguktOAUi9ET_h-FH1DjpjqQI'); //yazivapp/bizzapp7 server key
//     var sender5 = new gcm.Sender('AIzaSyDJLuox8AJTgwCgcnUQnM_DvKJ0o7dxj3Y'); //babyshick server key
//     var sender6 = new gcm.Sender('AIzaSyAs0BR1AxGui8_NYBEGlZiIj6of2Yu0HT0'); //kotellApp server key
//     var sender7 = new gcm.Sender('AIzaSyAz1iIWRbqBzc2QupBNa5D8kFcV8XaM3OY'); //knockout customer server key
//     var sender8 = new gcm.Sender('AIzaSyAK523f_-xnee-OrasfijFgZ8nmO39gveg'); //knockout manager server key
//     var sender9 = new gcm.Sender('AIzaSyCj0HRRxFOOotzKvg7Wwdz5imiHQuOfkgA'); //migdal app manager server key
//     var sender11 = new gcm.Sender('AIzaSyCNSWdCF7CN6Z9U4ga5nr9fBRrIQcX4f_E'); //FintenssApp English app customer server key
//     var sender11 = new gcm.Sender('AIzaSyDUpPUfkOB3Phkp8B16NmpmuJ835ekD-lg'); //FintenssApp English app Manager server key
//     var sender12 = new gcm.Sender('AIzaSyA_BZdOrJYvyiDFCeDKpdxis7tp1p4u51k'); //Uzan app customer server key
//     var sender13= new gcm.Sender('AIzaSyBCCeXTKPGsxqoUSaOEZ2gFINR3VvvLMzo'); //Uzan app manager server key
//     var sender14= new gcm.Sender('AIzaSyDdm7NWBa72zALiOWtiDZ4gH-x0HhhTUKc'); //Rabin app user server key
//     var sender15= new gcm.Sender('AIzaSyD6Z4BHfNK4Q8_nwTDm3qSTlJacTKklT98'); //Hibuki app user server key
//     var sender16= new gcm.Sender('AIzaSyAVNOuv4K5dSDn5IwHyBrh4IWKAtVhxRBs'); //Adel app user server key
//     var sender17= new gcm.Sender('AIzaSyAIaAtBY1iBJWn-lN468fiaNTRbcM44rQ4'); //Deckon app user server key
//     var sender18= new gcm.Sender('AIzaSyD3zKUG5iM79M9u4ECZAECjhYD2dHPq_Do'); //Natzrat app user server key
//     var sender19= new gcm.Sender('AIzaSyBo3T40yEkerwP0dwq3L9CIA7UoAxgA19A'); //Moshe app user/maanger server key
//     var sender20= new gcm.Sender('AIzaSyDsVFL0TUNuKscg2miPS-6B7lI2fXuhhcw'); //Neta app user/maanger server key
//     var sender21= new gcm.Sender('AIzaSyAFM-ZXKlsOHC4JrIA8ZCvNylWHj57RPdU'); //safir app user/maanger server key
//     var sender22= new gcm.Sender('AIzaSyD2Hhqz1NCsmgsDIDpIPs_ao8V69b8F7Ho'); //Rafael app user/maanger server key
//     var sender23= new gcm.Sender('AIzaSyBVsN2T4KtxuadxeJAncoUhWTvPtzFKl0E'); //Nativ app user/maanger server key
//     var sender24= new gcm.Sender('AIzaSyCUG1k3qNGC71qziLzqkD-FEyL2SjRcLDc'); //Ashdodhayom app user /maanger server key
//     var sender25= new gcm.Sender('AIzaSyC2dEBrCm4xGTDLSZfsVZ5aKMWd0NZeAS0'); //Sivan app user /maanger server key 
//     //IOS Pem files
//     // var serviceIOS = new apn.Provider({
//     //     cert: "./resources/ApplePushFitness.pem",
//     //     key: "./resources/ApplePushFitness.pem",
//     //     production: true
//     // }); //Fitness App Cutomer pem 
//     var serviceIOS="";
//     /*  var serviceIOS = new apn.Provider({
//          cert: "./resources/DevPushFitness.pem",
//          key: "./resources/DevPushFitness.pem",
//          production: false
//      }); */ //Fitness App Cutomer pem 
//     //IOS Pem files
//     // var serviceIOSMan = new apn.Provider({
//     //     cert: "./resources/ManagerApplePush.pem",
//     //     key: "./resources/ManagerApplePush.pem",
//     //     production: true
//     // }); //Fitness App manager pem old file
//     var serviceIOSMan="";
//    /* var serviceIOSManNew = new apn.Provider({
//         cert: "./resources/fitnessManagerdev.pem",
//         key: "./resources/fitnessManagerdev.pem",
//         production: false
//     }); //Fitness App manager pem new file  
// 	*/
// 	var serviceIOSManNew="";
//     // var serviceBizz6 = new apn.Provider({
//     //     cert: "./resources/BizzApp6Dis.pem",
//     //     key: "./resources/BizzApp6Dis.pem",
//     //     production: true
//     // }); //Bizz App customer pem

//     // var serviceBizz7 = new apn.Provider({
//     //     cert: "./resources/BizzApp7ApplePush.pem",
//     //     key: "./resources/BizzApp7ApplePush.pem",
//     //     production: true
//     // });

//     /*knockout customer push notifications*/
//     // var serviceknockout1 = new apn.Provider({
//     //     cert: "./resources/knockoutPushApple.pem",
//     //     key: "./resources/knockoutPushApple.pem",
//     //     production: true
//     // });
	
// 	/*knockout manager push notifications*/
//     var managerknockout = new apn.Provider({
//         cert: "./resources/KOM_PN_Dis.pem",
//         key: "./resources/KOM_PN_Dis.pem",
//         production: true
//     });

//     /*Kotel customer push development certificate*/
//     var servicekotel = new apn.Provider({
//         cert: "./resources/KotelAppDevPush.pem",
//         key: "./resources/KotelAppDevPush.pem",
//         production: false
//     });

// /*Migdal push production certificate*/
//      var serviceMigdal = new apn.Provider({
//         cert: "./resources/migdalProd.pem",
//         key: "./resources/migdalProd.pem",
//         production: true
//     });

// //uzan push notification manager
// var serviceUzanManager = new apn.Provider({
//         cert: "./resources/uzanAppDev.pem",
//         key: "./resources/uzanAppDev.pem",
//         production: false
//     });

// //Uzan push notification user
// var serviceUzanCustomer = new apn.Provider({
//         cert: "./resources/uzancustomerdev.pem",
//         key: "./resources/uzancustomerdev.pem",
//         production: false
//     });

// //rabin pushnotification user
// var serviceRabinCustomer = new apn.Provider({
//         cert: "./resources/RavincustomerDev.pem",
//         key: "./resources/RavincustomerDev.pem",
//         production: false
//     });

// var serviceHibukiCustomer = new apn.Provider({
//         cert: "./resources/kindergardenDev.pem",
//         key: "./resources/kindergardenDev.pem",
//         production: false
//     });

// var serviceAdelCustomer = new apn.Provider({
//         cert: "./resources/adelApp.pem",
//         key: "./resources/adelApp.pem",
//         production: false
//     });


// var serviceNetaCustomer = new apn.Provider({
//         cert: "./resources/netaApp.pem",
//         key: "./resources/netaApp.pem",
//         production: false
//     });

// var serviceMosheManager = new apn.Provider({
//         cert: "./resources/ilmoshe.pem",
//         key: "./resources/ilmoshe.pem",
//         production: false
//     });


// var serviceMosheCustomer = new apn.Provider({
//         cert: "./resources/mosheCustomerDev.pem",
//         key: "./resources/mosheCustomerDev.pem",
//         production: false
//     });

// var serviceNativCustomer = new apn.Provider({
//         cert: "./resources/NativCustomer.pem",
//         key: "./resources/NativCustomer.pem",
//         production: false
//     });


// var serviceNatzratCustomer = new apn.Provider({
//         cert: "./resources/natzratChangeCustomer.pem",
//         key: "./resources/natzratChangeCustomer.pem",
//         production: false
//     });

// var serviceRafaelCustomer = new apn.Provider({
//         cert: "./resources/rafaelCustomer.pem",
//         key: "./resources/rafaelCustomer.pem",
//         production: false
//     });

// // var serviceSafirManager = new apn.Provider({
// //         cert: "./resources/ilSafir.pem",
// //         key: "./resources/ilSafir.pem",
// //         production: false
// //     });

// var serviceSafirCustomer = new apn.Provider({
//         cert: "./resources/SafirCustomer.pem",
//         key: "./resources/SafirCustomer.pem",
//         production: false
//     });

// var serviceDeckonCustomer = new apn.Provider({
//         cert: "./resources/deckApp.pem",
//         key: "./resources/deckApp.pem",
//         production: false
//     });

// var serviceSivanCustomer = new apn.Provider({
//          cert: "./resources/SivanApp.pem",
//          key: "./resources/SivanApp.pem",
//          production: false

//     });
// var serviceAshdodhayCustomer = new apn.Provider({
//          cert: "./resources/ashododhy.pem",
//          key: "./resources/ashododhy.pem",
//          production: false

//     });

//     /*Kotel customer push production certificate*/
//     // var servicekotel = new apn.Provider({
//     //     cert: "./resources/KotelAppApplePush.pem",
//     //     key: "./resources/KotelAppApplePush.pem",
//     //     production: true
//     // });

//     /*knockout customer push notifications*/

//     //Bizz App customer pem   
//     //var serverKey = 'AIzaSyBk7spwgAT8amwdwPWRAqBqTFxGyMIisPM'; //put your server key here 
//     //var fcm = new FCM(serverKey);
//     var fcmPushnotification = {};
//     var mysql1 = require('mysql');
//     var connection1 = mysql1.createConnection({
//         host: 'localhost',
//         user: 'root',
//         password: 'mindcrew01',
//         database: 'fitnessapp'
//     });
//     fcmPushnotification.fcmPushnotificationFunction = function(notification_type, dataResult, message1, user_type, app_id_forsendPushMessageToAll,group_id,group_name) {


//         switch (notification_type) {

//             case "1_lesson_left":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }

//                         //console.log('Connected Id:- ' + connection1.threadId);
//                     });




//                     //connection1.query("SELECT a.*,b.name,a.device_type from user_registration_token as a,userinfo as b where a.user_id=b.id and (a.`user_type`='customer' OR a.`user_type`='normal') AND b.lesson_no=1 AND a.app_id=1 GROUP BY a.id", function(error, results, fields) {
//                     connection1.query("SELECT a.*,b.name,a.device_type from user_registration_token as a,userinfo as b where a.user_id=b.id and (a.`user_type`='customer' OR a.`user_type`='normal') AND b.lesson_no=1 GROUP BY a.id", function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {

//                         } else {

//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);
//                             for (x in dataResult) {
//                                 if (dataResult[x].device_type == 'android' && user_type == '1') {

//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         // One lesson left in your card
//                                         // Hello ' + dataResult[x].name + ', you left only one lesson in your training card

//                                         notification: {
//                                             title: 'נשאר אימון אחד בכרטיסיית האימונים שלך',
//                                             body: 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים'
//                                         }
//                                     });
//                                     message.addData('message', 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים');
//                                     message.addData('type', "1_lesson_left");
//                                     message.addData('appname', "fitnessApp");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'android' && user_type == '7') {
//                                     //console.log("1 lesson left android customer");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({


//                                         notification: {
//                                             //title: 'נשאר אימון אחד בכרטיסיית האימונים שלך',
//                                             title: 'הודעה חדשה מנוקאאוט',
//                                             body: 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים'
//                                         }
//                                     });
//                                     message.addData('message', 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים');
//                                     message.addData('type', "1_lesson_left");
//                                     message.addData('appname', "knockout");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender7.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'android' && user_type == '16') {

//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         // One lesson left in your card
//                                         // Hello ' + dataResult[x].name + ', you left only one lesson in your training card

//                                         notification: {
//                                             title: 'נותר שיעור אחרון',
//                                             body: 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים'
//                                         }
//                                     });
//                                     message.addData('message', 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים');
//                                     message.addData('type', "1_lesson_left");
//                                     message.addData('appname', "Moshe");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender19.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios' && user_type == '1') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים'
//                                     });
//                                     var data1 = {};
//                                     data1.type = "1_lesson_left";
//                                     data1.data = 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים';
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.bizz.fitnessapp";
//                                     note.type = "1_lesson_left";
//                                     serviceIOS.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceIOS.shutdown();
//                                 } else if (dataResult[x].device_type == 'ios' && user_type == '7') {
//                                     console.log("1 lesson left ios customer");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     console.log("pp");
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים'
//                                     });
//                                     var data1 = {};
//                                     data1.type = "1_lesson_left";
//                                     data1.data = 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים';
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.Knockout";
//                                     note.type = "1_lesson_left";
//                                     serviceknockout1.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceknockout1.shutdown();
//                                 } else if (dataResult[x].device_type == 'ios' && user_type == '16') {
//                                     console.log("1 lesson left ios customer");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     console.log("pp");
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים'
//                                     });
//                                     var data1 = {};
//                                     data1.type = "1_lesson_left";
//                                     data1.data = 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים';
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.MosheCustomer";//Moshe APP's Bundle ID
//                                     note.type = "1_lesson_left";
//                                     serviceMosheCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceMosheCustomer.shutdown();
//                                 }
//                             }



//                             connection1.query("SELECT a.*,b.name from user_registration_token as a,userinfo as b where a.user_id=b.id and (a.`user_type`='manager') GROUP BY a.id", function(error, results, fields) {



//                                 if (error) throw error;
//                                 if (results == '') {} else {

//                                     var dataResult = results;
//                                     //var dataResult=JSON.parse(dataResult);
//                                     for (x in dataResult) {

//                                         if (dataResult[x].device_type == 'android' && user_type == '1') {
//                                             var deviceToken = dataResult[x].registration_token;
//                                             var message = new gcm.Message({
//                                                 // One lesson left in your card
//                                                 // Hello ' + dataResult[x].name + ', you left only one lesson in your training card

//                                                 notification: {
//                                                     title: "נותר אימון אחד בכרטיסיה",
//                                                     body: '' + message1 + ' נותר אימון 1'
//                                                 }
//                                             });
//                                             //message.addData('message', 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים');
//                                             message.addData('message', '' + message1 + ' נותר אימון 1');




//                                             message.addData('type', "1_lesson_left");
//                                             message.addData('appname', "fitnessApp");
//                                             message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                             var regTokens = [deviceToken];
//                                             sender1.send(message, {
//                                                 registrationTokens: regTokens
//                                             }, function(err, response) {
//                                                 if (err) console.error(err);
//                                                 else console.log(response);
//                                             });
//                                         } else if (dataResult[x].device_type == 'android' && user_type == '7') {
//                                             console.log("1 lesson left android manager");
//                                             var deviceToken = dataResult[x].registration_token;
//                                             var message = new gcm.Message({
//                                                 // One lesson left in your card
//                                                 // Hello ' + dataResult[x].name + ', you left only one lesson in your training card

//                                                 notification: {
//                                                     //title: "נותר אימון אחד בכרטיסיה",
//                                                     title: "הודעה חדשה",
//                                                     body: '' + message1 + ' נותר אימון 1'
//                                                 }
//                                             });
//                                             //message.addData('message', 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים');
//                                             message.addData('message', '' + message1 + ' נותר אימון 1');




//                                             message.addData('type', "1_lesson_left");
//                                             message.addData('appname', "knockout");
//                                             message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                             var regTokens = [deviceToken];
//                                             sender8.send(message, {
//                                                 registrationTokens: regTokens
//                                             }, function(err, response) {
//                                                 if (err) console.error(err);
//                                                 else console.log(response);
//                                             });

//                                         } else if (dataResult[x].device_type == 'android' && user_type == '9') {
//                                             //console.log("1 lesson left android manager");
//                                             var deviceToken = dataResult[x].registration_token;
//                                             var message = new gcm.Message({
//                                                 // One lesson left in your card
//                                                 // Hello ' + dataResult[x].name + ', you left only one lesson in your training card

//                                                 notification: {
//                                                     //title: "נותר אימון אחד בכרטיסיה",
//                                                     title: "one lesson left in customer account",
//                                                     body: 'one lesson left in ' + message1 + ' account'
//                                                 }
//                                             });
//                                             //message.addData('message', 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים');
//                                             message.addData('message', 'one lesson left in ' + message1 + ' account');




//                                             message.addData('type', "1_lesson_left");
//                                             message.addData('appname', "fitnessAppEng");
//                                             message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                             var regTokens = [deviceToken];
//                                             sender11.send(message, {
//                                                 registrationTokens: regTokens
//                                             }, function(err, response) {
//                                                 if (err) console.error(err);
//                                                 else console.log(response);
//                                             });

//                                         } else if (dataResult[x].device_type == 'ios' && user_type == '1') {


//                                             var deviceToken = dataResult[x].registration_token;
//                                             var tokens = [deviceToken];

//                                             var note = new apn.Notification({
//                                                 alert: '' + message1 + ' נותר אימון 1'
//                                             });
//                                             var data1 = {};
//                                             data1.type = "1_lesson_left";
//                                             data1.data = '' + message1 + ' נותר אימון 1';
//                                             note.payload = data1;
//                                             // The topic is usually the bundle identifier of your application.
//                                             note.topic = "com.bizz.fitnessManager";
//                                             note.type = "1_lesson_left";
//                                             serviceIOSManNew.send(note, tokens).then(result => {
//                                                 console.log("sent:", result.sent.length);
//                                                 console.log("failed:", result.failed.length);
//                                                 console.log(result.failed);
//                                             });
//                                             // For one-shot notification tasks you may wish to shutdown the connection
//                                             // after everything is sent, but only call shutdown if you need your 
//                                             // application to terminate.
//                                             serviceIOSManNew.shutdown();
//                                         }
										
// 										else if (dataResult[x].device_type == 'ios' && user_type == '7') {


//                                             var deviceToken = dataResult[x].registration_token;
//                                             var tokens = [deviceToken];

//                                             var note = new apn.Notification({
//                                                 alert: '' + message1 + ' נותר אימון 1'
//                                             });
//                                             var data1 = {};
//                                             data1.type = "1_lesson_left";
//                                             data1.data = '' + message1 + ' נותר אימון 1';
//                                             note.payload = data1;
//                                             // The topic is usually the bundle identifier of your application.
//                                             note.topic = "com.Bizz.KnockoutManager";
//                                             note.type = "1_lesson_left";
//                                             managerknockout.send(note, tokens).then(result => {
//                                                 console.log("sent:", result.sent.length);
//                                                 console.log("failed:", result.failed.length);
//                                                 console.log(result.failed);
//                                             });
//                                            managerknockout.shutdown();
//                                         }




//                                     }
//                                 }
//                             });




//                         }
//                     });




//                     //connection1.query("SELECT a.*,b.name from user_registration_token as a,userinfo as b where a.user_id=b.id and (a.`user_type`='manager') AND a.app_id=1 GROUP BY a.id", function(error, results, fields) {




//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//             case "1_week_left":
//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     console.log(dataResult[x].registration_token);
//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         var message = new gcm.Message({
//                             notification: {
//                                 //Your lesson will expire by next week
//                                 //Hello ' + dataResult[x].name + ', you left only one lesson in your training card
//                                 title: 'תוקף כרטיסיית האימנוים שלך יפוג בעוד שבוע',
//                                 body: 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים'
//                             }
//                         });
//                         message.addData('message', 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים');
//                         message.addData('type', "1_week_left");
//                         message.addData('appname', "fitnessApp");
//                         message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                         var regTokens = [deviceToken];
//                         sender.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             else console.log(response);
//                         });
//                     } else if (dataResult[x].device_type == 'ios') {
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים'
//                         });
//                         var data1 = {};
//                         data1.type = "1_week_left";
//                         data1.data = 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים';
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.bizz.fitnessapp";
//                         note.type = "1_week_left";
//                         serviceIOS.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);
//                         });
//                         // For one-shot notification tasks you may wish to shutdown the connection
//                         // after everything is sent, but only call shutdown if you need your 
//                         // application to terminate.
//                         serviceIOS.shutdown();
//                     }
//                 }
//                 break;
//                 case "1_week_left_FintnessEng":
//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     console.log(dataResult[x].registration_token);
//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         var message = new gcm.Message({
//                             notification: {
//                                 //Your lesson will expire by next week
//                                 //Hello ' + dataResult[x].name + ', you left only one lesson in your training card
//                                 title: 'Your lesson will expire by next week',
//                                 body: 'Hello ' + dataResult[x].name + ', you left only one lesson in your training card'
//                             }
//                         });
//                         message.addData('message', 'Hello ' + dataResult[x].name + ', you left only one lesson in your training card');
//                         message.addData('type', "1_week_left");
//                         message.addData('appname', "fitnessAppEng");
//                         message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                         var regTokens = [deviceToken];
//                         sender11.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             else console.log(response);
//                         });
//                     } else if (dataResult[x].device_type == 'ios') {
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים'
//                         });
//                         var data1 = {};
//                         data1.type = "1_week_left";
//                         data1.data = 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים';
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.bizz.fitnessapp";
//                         note.type = "1_week_left";
//                         serviceIOS.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);
//                         });
//                         // For one-shot notification tasks you may wish to shutdown the connection
//                         // after everything is sent, but only call shutdown if you need your 
//                         // application to terminate.
//                         serviceIOS.shutdown();
//                     }
//                 }
//                 break;
//              case "1_week_left_knocknot":
//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     console.log(dataResult[x].registration_token);
//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         var message = new gcm.Message({
//                             notification: {
//                                 //Your lesson will expire by next week
//                                 //Hello ' + dataResult[x].name + ', you left only one lesson in your training card
//                                 title: 'הודעה חדשה מנוקאאוט',
//                                 body: 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים'
//                             }
//                         });
//                         message.addData('message', 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים');
//                         message.addData('type', "1_week_left_knocknot");
//                         message.addData('appname', "knockout");
//                         message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                         var regTokens = [deviceToken];
//                         sender7.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             else console.log(response);
//                         });
//                     } else if (dataResult[x].device_type == 'ios') {
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים'
//                         });
//                         var data1 = {};
//                         data1.type = "1_week_left_knocknot";
//                         data1.data = 'שלום , ' + dataResult[x].name + ' , נשאר לך אימון אחד בכרטיסיית האימונים';
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.Knockout";
//                         note.type = "1_week_left_knocknot";
//                         serviceknockout1.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);
//                         });
//                         // For one-shot notification tasks you may wish to shutdown the connection
//                         // after everything is sent, but only call shutdown if you need your 
//                         // application to terminate.
//                         serviceknockout1.shutdown();
//                     }
//                 }
//                 break;
//             case "lesson_booked_by_customer":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }

//                         console.log('Connected Id:- ' + connection1.threadId);
//                     });
//                     //connection1.query("SELECT a.*,b.name from user_registration_token as a,userinfo as b where a.user_id=b.id and a.`user_type`='manager' and a.app_id=1 GROUP BY a.id", function(error, results, fields) {

//                     console.log("SELECT a.*,b.name from user_registration_token as a,userinfo as b where a.user_id=b.id and a.`user_type`='manager' and a.app_id="+user_type+" GROUP BY a.id");
//                     connection1.query("SELECT a.*,b.name from user_registration_token as a,userinfo as b where a.user_id=b.id and a.`user_type`='manager' and a.app_id="+user_type+" GROUP BY a.id", function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {

//                         } else {
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);
//                             for (x in dataResult) {

//                                 if (dataResult[x].device_type == 'android' && user_type == '1') {


//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //Lesson is booked by customer
//                                         //Hello ' + dataResult[x].name + ', lesson has booked by customer
//                                         notification: {
//                                             title: 'השיעור הוזמן על ידי הלקוח',
//                                             body: 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח' + message1
//                                         }
//                                     });
//                                     message.addData('message', 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח ' + message1);
//                                     message.addData('type', "lesson_booked_by_customer");
//                                     message.addData('appname', "fitnessApp");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender1.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 }
//                                 else if (dataResult[x].device_type == 'android' && user_type == '7') {

//                                     console.log("lesson booked knockout");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
                                       
//                                         notification: {
//                                             title: 'הודעה חדשה',
//                                             body: 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח' + message1
//                                         }
//                                     });
//                                     message.addData('message', 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח' + message1);
//                                     message.addData('type', "lesson_booked_by_customer");
//                                     message.addData('appname', "knockout");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender8.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'android' && user_type == '9') {

//                                     console.log("lesson booked Fitness Merge app app_id "+dataResult[x].app_id+"");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //Lesson is booked by customer
//                                         //Hello ' + dataResult[x].name + ', lesson has booked by customer
//                                         notification: {
//                                             //title: 'השיעור הוזמן על ידי הלקוח',
//                                             title: 'Lesson is booked by customer',
//                                             body: 'Hello ' + dataResult[x].name + ', lesson has booked by '+message1+''
//                                             //body: 'hello knockout'
//                                         }
//                                     });
//                                     message.addData('message', 'Hello ' + dataResult[x].name + ', lesson has booked by '+message1+'');
//                                     message.addData('type', "lesson_booked_by_customer");
//                                     message.addData('appname', "fitnessAppEng");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender11.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'android' && user_type == '16') {

//                                     console.log("lesson booked Moshe app app_id "+dataResult[x].app_id+"");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         notification: {
//                                             title: 'רישום לשיעור',
//                                             body: 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח' + message1
//                                         }
//                                     });
//                                     message.addData('message', 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח' + message1);
//                                     message.addData('type', "lesson_booked_by_customer");
//                                     message.addData('appname', "Moshe");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender19.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'android' && user_type == '19') {

//                                     console.log("lesson booked safir app app_id "+dataResult[x].app_id+"");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         notification: {
//                                             title: 'רישום לשיעור',
//                                             body: 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח' + message1
//                                         }
//                                     });
//                                     message.addData('message', 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח' + message1);
//                                     message.addData('type', "lesson_booked_by_customer");
//                                     message.addData('appname', "safir");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender21.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios' && user_type == '1') {

//                                     var deviceToken = dataResult[x].registration_token;
//                                     var tokens = [deviceToken];



//                                     var note = new apn.Notification({
//                                         alert: 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח ' + message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "lesson_booked_by_customer";
//                                     data1.data = 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח ' + message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.bizz.fitnessManager";
//                                     note.type = "lesson_booked_by_customer";
//                                     serviceIOSManNew.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceIOSManNew.shutdown();
//                                 }else if (dataResult[x].device_type == 'ios' && user_type == '16') {

//                                     var deviceToken = dataResult[x].registration_token;
//                                     var tokens = [deviceToken];



//                                     var note = new apn.Notification({
//                                         alert: 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח ' + message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "lesson_booked_by_customer";
//                                     data1.data = 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח ' + message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.ilMoshe";//Moshe Apps Bundle ID
//                                     note.type = "lesson_booked_by_customer";
//                                     serviceMosheManager.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceMosheManager.shutdown();
//                                 } else if (dataResult[x].device_type == 'ios' && user_type == '19') {

//                                     var deviceToken = dataResult[x].registration_token;
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח ' + message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "lesson_booked_by_customer";
//                                     data1.data = 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח ' + message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.ilSafir";//Moshe Apps Bundle ID
//                                     note.type = "lesson_booked_by_customer";
//                                     serviceSafirManager.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceSafirManager.shutdown();
//                                 } else if (dataResult[x].device_type == 'ios' && user_type == '7') {
									

//                                     var deviceToken = dataResult[x].registration_token;
//                                     var tokens = [deviceToken];



//                                     var note = new apn.Notification({
//                                         alert: 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח ' + message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "lesson_booked_by_customer";
//                                     data1.data = 'שלום , ' + dataResult[x].name + ', שיעור הוזמן על ידי הלקוח ' + message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.KnockoutManager";
//                                     note.type = "lesson_booked_by_customer";
//                                     managerknockout.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     managerknockout.shutdown();
//                                 }
//                             }


//                             /**/


//                             /**/

//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//             case "lesson_cancel_by_customer":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }

//                         console.log('Connected Id:- ' + connection1.threadId);
//                     });
//                     console.log("SELECT a.*,b.name from user_registration_token as a,userinfo as b where a.user_id=b.id and a.`user_type`='manager' and a.app_id="+user_type+" GROUP BY a.id");
//                     connection1.query("SELECT a.*,b.name from user_registration_token as a,userinfo as b where a.user_id=b.id and a.`user_type`='manager' and a.app_id="+user_type+" GROUP BY a.id", function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {

//                         } else {
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);
//                             for (x in dataResult) {
//                                 if (dataResult[x].device_type == 'android' && user_type == '1') {
//                                     console.log(dataResult[x].registration_token);
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         notification: {
//                                             //Lesson cancel by customer
//                                             //Hello ' + dataResult[x].name + ', lesson has been cancel by customer
//                                             title: 'Lesson cancel by customer',
//                                             body: 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1
//                                         }
//                                     });
//                                     message.addData('message', 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1);
//                                     message.addData('type', "lesson_cancel_by_customer");
//                                     message.addData('appname', "fitnessApp");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender1.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'android' && user_type == '7') {
//                                     console.log("knoout manager noti");
//                                     console.log(dataResult[x].registration_token);
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         notification: {
//                                             //Lesson cancel by customer
//                                             //Hello ' + dataResult[x].name + ', lesson has been cancel by customer
//                                             //title: 'השיעור בוטל על ידי הלקוח',
//                                             title: 'הודעה חדשה',
//                                             body: 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1
//                                         }
//                                     });
//                                     message.addData('message', 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1);
//                                     message.addData('type', "lesson_cancel_by_customer");
//                                     message.addData('appname', "knockout");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender8.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'android' && user_type == '9') {
//                                     console.log("Lesson cancel by Fitness English customer app_id "+dataResult[x].app_id+"");
//                                     console.log(dataResult[x].app_id);
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         notification: {
//                                             //Lesson cancel by customer
//                                             //Hello ' + dataResult[x].name + ', lesson has been cancel by customer
//                                             //title: 'השיעור בוטל על ידי הלקוח',
//                                             title: 'Lesson cancel by customer',
//                                             body: 'Hello ' + dataResult[x].name + ', lesson has been cancel by '+message1+''
//                                         }
//                                     });
//                                     message.addData('message', 'Hello ' + dataResult[x].name + ', lesson has been cancel by '+message1+'');
//                                     message.addData('type', "lesson_cancel_by_customer");
//                                     message.addData('appname', "fitnessAppEng");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender11.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'android' && user_type == '16') {
//                                     console.log("Lesson cancel by Moshe  customer app_id "+dataResult[x].app_id+"");
//                                     console.log(dataResult[x].app_id);
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         notification: {
//                                             title: 'ביטול רישום לשיעור',
//                                             body: 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1
//                                         }
//                                     });
//                                     message.addData('message', 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1);
//                                     message.addData('type', "lesson_cancel_by_customer");
//                                     message.addData('appname', "Moshe");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender19.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'android' && user_type == '19') {
//                                     console.log("Lesson cancel by safir  customer app_id "+dataResult[x].app_id+"");
//                                     console.log(dataResult[x].app_id);
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         notification: {
//                                             title: 'ביטול רישום לשיעור',
//                                             body: 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1
//                                         }
//                                     });
//                                     message.addData('message', 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1);
//                                     message.addData('type', "lesson_cancel_by_customer");
//                                     message.addData('appname', "Safir");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender21.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios' && user_type == '1') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "lesson_cancel_by_customer";
//                                     data1.data = 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.bizz.fitnessManager";
//                                     note.type = "lesson_cancel_by_customer";
//                                     serviceIOSManNew.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceIOSManNew.shutdown();
//                                 }else if (dataResult[x].device_type == 'ios' && user_type == '16') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "lesson_cancel_by_customer";
//                                     data1.data = 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.ilMoshe"; //Moshe App
//                                     note.type = "lesson_cancel_by_customer";
//                                     serviceMosheManager.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceMosheManager.shutdown();
//                                 } else if (dataResult[x].device_type == 'ios' && user_type == '19') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "lesson_cancel_by_customer";
//                                     data1.data = 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.ilSafir"; //Moshe App
//                                     note.type = "lesson_cancel_by_customer";
//                                     serviceSafirManager.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceSafirManager.shutdown();
//                                 } else if (dataResult[x].device_type == 'ios' && user_type == '7') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "lesson_cancel_by_customer";
//                                     data1.data = 'שלום , ' + dataResult[x].name + ' , שיעור בוטל על ידי הלקוח ' + message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.KnockoutManager";
//                                     note.type = "lesson_cancel_by_customer";
//                                     managerknockout.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     managerknockout.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;



//             case "Notification_to_kotell":

//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }

//                         console.log('Connected Id:- ' + connection1.threadId);
//                     });


//                     var queryStr = "SELECT * from user_registration_token as a where (`user_type`='customer' OR `user_type`='normal') AND app_id = '6'";

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {

//                         } else {
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);
//                             for (x in dataResult) {
//                                 if (dataResult[x].device_type == 'android') {
//                                     console.log(dataResult[x].registration_token);
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'Holly Blessing',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "Notification_to_kotell");
//                                     message.addData('appname', "KotellApp");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender6.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: 'Holly Blessing'
//                                     });
//                                     var data1 = {};
//                                     data1.type = "Notification_to_kotell";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.leadersapp.HollyBlessing";
//                                     note.type = "Notification_to_kotell";
//                                     servicekotel.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     servicekotel.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;



//             case "Notification_to_migdal":

//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }

//                         console.log('Connected Id:- ' + connection1.threadId);
//                     });


//                     var queryStr = "SELECT * from user_registration_token as a where (`user_type`='customer' OR `user_type`='normal') AND app_id = '8'";

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {

//                         } else {
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);
//                             for (x in dataResult) {
//                                 if (dataResult[x].device_type == 'android') {
//                                     console.log(dataResult[x].registration_token);
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'Holly Blessing',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "Notification_to_migdal");
//                                     message.addData('appname', "migdal");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender9.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 }
//                                   else if(dataResult[x].device_type == 'ios'){
//                                                                     var deviceToken = dataResult[x].registration_token;
//                                                                     var tokens = [deviceToken];

//                                                                     var note = new apn.Notification({
//                                                                         alert: message1
//                                                                     });
//                                                                     var data1 = {};
//                                                                     data1.type = "Notification_to_migdal";
//                                                                     data1.data = message1;
//                                                                     note.payload = data1;
//                                                                     // The topic is usually the bundle identifier of your application.
//                                                                     note.topic = "com.Bizz.InsuranceAgency";
//                                                                     note.type = "Notification_to_migdal";
//                                                                     serviceMigdal.send(note, tokens).then(result => {
//                                                                         console.log("sent:", result.sent.length);
//                                                                         console.log("failed:", result.failed.length);
//                                                                         console.log(result.failed);
//                                                                     });
//                                                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                                                     // after everything is sent, but only call shutdown if you need your 
//                                                                     // application to terminate.
//                                                                     serviceMigdal.shutdown();
//                                                                 } 
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;




//             case "new_msg_from_manager":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }

//                         console.log('Connected Id:- ' + connection1.threadId);
//                     });
//                     connection1.query("SELECT a.*,b.name from user_registration_token as a,userinfo as b where a.user_id=b.id and a.`user_type`='customer' GROUP BY a.id", function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {

//                         } else {
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);
//                             for (x in dataResult) {
//                                 if (dataResult[x].device_type == 'android' && user_type == '1') {
//                                     console.log(dataResult[x].registration_token);
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         // New message from manager
//                                         //Hello ' + dataResult[x].name + ', you have new message from manage
//                                         notification: {
//                                             title: 'הודעה חדשה ממיכל ממן',
//                                             body: 'ש לך הודעה חדשה'
//                                         }
//                                     });
//                                     message.addData('message', 'שלום , ' + dataResult[x].name + ' , יש לך הודעה חדשה ממיכל ממן');
//                                     message.addData('type', "new_msg_from_manager");
//                                     message.addData('appname', "fitnessApp");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 }

//                                 else if (dataResult[x].device_type == 'android' && user_type == '7 ') {
//                                     console.log(dataResult[x].registration_token);
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         // New message from manager
//                                         //Hello ' + dataResult[x].name + ', you have new message from manage
//                                         notification: {
//                                             title: 'הודעה חדשה מנוקאאוט',
//                                             body: 'שלום , ' + dataResult[x].name + ' , יש לך הודעה חדשה מנוקאאוט'
//                                         }
//                                     });
//                                     message.addData('message', 'שלום , ' + dataResult[x].name + ' , יש לך הודעה חדשה מנוקאאוט');
//                                     message.addData('type', "new_msg_from_manager");
//                                     message.addData('appname', "knockout");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender7.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'android' && user_type == '9') {
//                                     console.log(dataResult[x].registration_token);
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         // New message from manager
//                                         //Hello ' + dataResult[x].name + ', you have new message from manage
//                                         notification: {
//                                             title: 'New message from manager',
//                                             body: 'Hello ' + dataResult[x].name + ', you have new message from manage'
//                                         }
//                                     });
//                                     message.addData('message', 'Hello ' + dataResult[x].name + ', you have new message from manage');
//                                     message.addData('type', "new_msg_from_manager");
//                                     message.addData('appname', "fitnessAppEng");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender11.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios' && user_type == '1') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: 'שלום , ' + dataResult[x].name + ' , יש לך הודעה חדשה ממיכל ממן'
//                                     });
//                                     var data1 = {};
//                                     data1.type = "new_msg_from_manager";
//                                     data1.data = 'שלום , ' + dataResult[x].name + ' , יש לך הודעה חדשה ממיכל ממן';
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.bizz.fitnessManager";
//                                     note.type = "new_msg_from_manager";
//                                     serviceIOSMan.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceIOSMan.shutdown();
//                                 } else if (dataResult[x].device_type == 'ios' && user_type == '7') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: 'שלום , ' + dataResult[x].name + ' , יש לך הודעה חדשה מנוקאאוט'
//                                     });
//                                     var data1 = {};
//                                     data1.type = "new_msg_from_manager";
//                                     data1.data = 'שלום , ' + dataResult[x].name + ' , יש לך הודעה חדשה מנוקאאוט';
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.Knockout";
//                                     note.type = "new_msg_from_manager";
//                                     serviceknockout1.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceknockout1.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//             case "1_hours_before_lesson":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {

//                     /* var lesson_serverDateTime = moment.tz(new Date(), "Europe/Kiev").format("YYYY-MM-DD HH:mm:ss");
//                         var lesson_serverDateTime1 = moment.tz(new Date(), "Europe/Kiev").format();
//                         // console.log(lesson_serverDateTime+ "server time");
//                         var diff = Math.abs(new Date(dataResult[x].lesson_serverDateTime) - new Date(lesson_serverDateTime));
//                         var minutes = Math.floor((diff / 1000) / 60);
//                         //console.log(minutes +'-'+ dataResult[x].lesson_id);
//               if (dataResult[x].lesson_serverDateTime > new Date(lesson_serverDateTime)) {
//                             console.log("Got it");
//                         }
                        
//                         console.log(minutes); */

//                     //if (minutes==60 && (dataResult[x].lesson_serverDateTime > new Date(lesson_serverDateTime)) && dataResult[x].one_hour_before==0) {
//                     //if (minutes==186) {

//                     /* if (minutes==60 && (dataResult[x].lesson_serverDateTime > new Date(lesson_serverDateTime))) { */

//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             //you have a lesson in a hour
//                             //Hello ' + dataResult[x].name + ', you have a lesson in a hour
//                             notification: {
//                                 title: 'תזכורת להתחלת שיעור בעוד שעה',
//                                 body: 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה'
//                             }
//                         });
//                         message.addData('message', 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה');
//                         message.addData('type', "1_hours_before_lesson");
//                         message.addData('appname', "fitnessApp");
//                         message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                         var regTokens = [deviceToken];
//                         sender.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             else {
//                                 console.log("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "");
//                                 connection1.query("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "", function(error, results, fields) {
//                                     if (error) {
//                                         console.log(err);
//                                     }

//                                 });
//                             }
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                         console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה'
//                         });
//                         var data1 = {};
//                         data1.type = "1_hours_before_lesson";
//                         data1.data = 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה';
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.bizz.fitnessapp";
//                         note.type = "1_hours_before_lesson";
//                         serviceIOS.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         // For one-shot notification tasks you may wish to shutdown the connection
//                         // after everything is sent, but only call shutdown if you need your 
//                         // application to terminate.
//                         console.log("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "");
//                         connection1.query("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "", function(error, results, fields) {
//                             if (error) {
//                                 console.log(err);
//                             }

//                         });
//                         serviceIOS.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;
//             case "1_hours_before_lesson_fitnessEng":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {

//                     /* var lesson_serverDateTime = moment.tz(new Date(), "Europe/Kiev").format("YYYY-MM-DD HH:mm:ss");
//                         var lesson_serverDateTime1 = moment.tz(new Date(), "Europe/Kiev").format();
//                         // console.log(lesson_serverDateTime+ "server time");
//                         var diff = Math.abs(new Date(dataResult[x].lesson_serverDateTime) - new Date(lesson_serverDateTime));
//                         var minutes = Math.floor((diff / 1000) / 60);
//                         //console.log(minutes +'-'+ dataResult[x].lesson_id);
//               if (dataResult[x].lesson_serverDateTime > new Date(lesson_serverDateTime)) {
//                             console.log("Got it");
//                         }
                        
//                         console.log(minutes); */

//                     //if (minutes==60 && (dataResult[x].lesson_serverDateTime > new Date(lesson_serverDateTime)) && dataResult[x].one_hour_before==0) {
//                     //if (minutes==186) {

//                     /* if (minutes==60 && (dataResult[x].lesson_serverDateTime > new Date(lesson_serverDateTime))) { */

//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             //you have a lesson in a hour
//                             //Hello ' + dataResult[x].name + ', you have a lesson in a hour
//                             notification: {
//                                 title: 'you have a lesson in a hour',
//                                 body: 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה'
//                             }
//                         });
//                         message.addData('message', 'Hello ' + dataResult[x].name + ', you have a lesson in a hour');
//                         message.addData('type', "1_hours_before_lesson");
//                         message.addData('appname', "fitnessAppEng");
//                         message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                         var regTokens = [deviceToken];
//                         sender11.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             else {
//                                 console.log("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "");
//                                 connection1.query("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "", function(error, results, fields) {
//                                     if (error) {
//                                         console.log(err);
//                                     }

//                                 });
//                             }
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                         console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה'
//                         });
//                         var data1 = {};
//                         data1.type = "1_hours_before_lesson";
//                         data1.data = 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה';
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.bizz.fitnessapp";
//                         note.type = "1_hours_before_lesson";
//                         serviceIOS.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         // For one-shot notification tasks you may wish to shutdown the connection
//                         // after everything is sent, but only call shutdown if you need your 
//                         // application to terminate.
//                         console.log("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "");
//                         connection1.query("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "", function(error, results, fields) {
//                             if (error) {
//                                 console.log(err);
//                             }

//                         });
//                         serviceIOS.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;
//             case "1_hours_before_lesson_knockout":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {

//                     /* var lesson_serverDateTime = moment.tz(new Date(), "Europe/Kiev").format("YYYY-MM-DD HH:mm:ss");
//                         var lesson_serverDateTime1 = moment.tz(new Date(), "Europe/Kiev").format();
//                         // console.log(lesson_serverDateTime+ "server time");
//                         var diff = Math.abs(new Date(dataResult[x].lesson_serverDateTime) - new Date(lesson_serverDateTime));
//                         var minutes = Math.floor((diff / 1000) / 60);
//                         //console.log(minutes +'-'+ dataResult[x].lesson_id);
//               if (dataResult[x].lesson_serverDateTime > new Date(lesson_serverDateTime)) {
//                             console.log("Got it");
//                         }
                        
//                         console.log(minutes); */

//                     //if (minutes==60 && (dataResult[x].lesson_serverDateTime > new Date(lesson_serverDateTime)) && dataResult[x].one_hour_before==0) {
//                     //if (minutes==186) {

//                     /* if (minutes==60 && (dataResult[x].lesson_serverDateTime > new Date(lesson_serverDateTime))) { */

//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             //you have a lesson in a hour
//                             //Hello ' + dataResult[x].name + ', you have a lesson in a hour
//                             notification: {
//                                 title: 'הודעה חדשה מנוקאאוט',
//                                 body: 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה'
//                             }
//                         });
//                         message.addData('message', 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה');
//                         message.addData('type', "1_hours_before_lesson_knockout");
//                         message.addData('appname', "knockout");
//                         message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                         var regTokens = [deviceToken];
//                         sender7.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             else {
//                                 console.log("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "");
//                                 connection1.query("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "", function(error, results, fields) {
//                                     if (error) {
//                                         console.log(err);
//                                     }

//                                 });
//                             }
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                         console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה'
//                         });
//                         var data1 = {};
//                         data1.type = "1_hours_before_lesson_knockout";
//                         data1.data = 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה';
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.Knockout";
//                         note.type = "1_hours_before_lesson_knockout";
//                         serviceknockout1.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         // For one-shot notification tasks you may wish to shutdown the connection
//                         // after everything is sent, but only call shutdown if you need your 
//                         // application to terminate.
//                         console.log("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "");
//                         connection1.query("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "", function(error, results, fields) {
//                             if (error) {
//                                 console.log(err);
//                             }

//                         });
//                         serviceknockout1.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;

//                 case "1_hours_before_lesson_moshe":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             //you have a lesson in a hour
//                             //Hello ' + dataResult[x].name + ', you have a lesson in a hour
//                             notification: {
//                                 title: 'תזכורת לשיעור בעוד שעה',
//                                 body: 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה'
//                             }
//                         });
//                         message.addData('message', 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה');
//                         message.addData('type', "1_hours_before_lesson_moshe");
//                         message.addData('appname', "Moshe");
//                         message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                         var regTokens = [deviceToken];
//                         sender19.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             else {
//                                 console.log("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "");
//                                 connection1.query("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "", function(error, results, fields) {
//                                     if (error) {
//                                         console.log(err);
//                                     }

//                                 });
//                             }
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                         console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה'
//                         });
//                         var data1 = {};
//                         data1.type = "1_hours_before_lesson_moshe";
//                         data1.data = 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה';
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.MosheCustomer";//Moshe App
//                         note.type = "1_hours_before_lesson_moshe";
//                         serviceMosheCustomer.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         // For one-shot notification tasks you may wish to shutdown the connection
//                         // after everything is sent, but only call shutdown if you need your 
//                         // application to terminate.
//                         console.log("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "");
//                         connection1.query("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "", function(error, results, fields) {
//                             if (error) {
//                                 console.log(err);
//                             }

//                         });
//                         serviceMosheCustomer.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;

//                 // case "1_hours_before_lesson_safir":

//                 // var dataResult = JSON.parse(dataResult);
//                 // for (x in dataResult) {
//                 //     if (dataResult[x].device_type == 'android') {
//                 //         var deviceToken = dataResult[x].registration_token;
//                 //         console.log(deviceToken + "-Android");
//                 //         var message = new gcm.Message({
//                 //             //you have a lesson in a hour
//                 //             //Hello ' + dataResult[x].name + ', you have a lesson in a hour
//                 //             notification: {
//                 //                 title: 'תזכורת לשיעור בעוד שעה',
//                 //                 body: 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה'
//                 //             }
//                 //         });
//                 //         message.addData('message', 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה');
//                 //         message.addData('type', "1_hours_before_lesson_safir");
//                 //         message.addData('appname', "Safir");
//                 //         message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                 //         var regTokens = [deviceToken];
//                 //         sender21.send(message, {
//                 //             registrationTokens: regTokens
//                 //         }, function(err, response) {
//                 //             if (err) console.error(err);
//                 //             else {
//                 //                 console.log("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "");
//                 //                 connection1.query("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "", function(error, results, fields) {
//                 //                     if (error) {
//                 //                         console.log(err);
//                 //                     }

//                 //                 });
//                 //             }
//                 //         });

//                 //     } else if (dataResult[x].device_type == 'ios') {
//                 //         console.log(deviceToken + "-Ios");
//                 //         var deviceToken = dataResult[x].registration_token;
//                 //         var tokens = [deviceToken];

//                 //         var note = new apn.Notification({
//                 //             alert: 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה'
//                 //         });
//                 //         var data1 = {};
//                 //         data1.type = "1_hours_before_lesson_safir";
//                 //         data1.data = 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה';
//                 //         note.payload = data1;
//                 //         // The topic is usually the bundle identifier of your application.
//                 //         note.topic = "";//Moshe App
//                 //         note.type = "1_hours_before_lesson_safir";
//                 //         serviceSafir.send(note, tokens).then(result => {
//                 //             console.log("sent:", result.sent.length);
//                 //             console.log("failed:", result.failed.length);
//                 //             console.log(result.failed);
//                 //         });
      
//                 //         console.log("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "");
//                 //         connection1.query("UPDATE tranning_lesson_usage SET one_hour_before = 1 WHERE customer_id = " + dataResult[x].customer_id + " AND lesson_id = " + dataResult[x].id + "", function(error, results, fields) {
//                 //             if (error) {
//                 //                 console.log(err);
//                 //             }

//                 //         });
//                 //         serviceSafir.shutdown();//
//                 //     }
//                 //     /* }  */

//                 // }
//                 // break;


//             case "Not_assign_user_lesson":
//                 //console.log("Not_assign_user_lesson");

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {

//                         //console.log("notification send");

//                         var deviceToken = dataResult[x].registration_token;
//                         var message = new gcm.Message({
//                             //You didn’t assign to training lesson for the next week
//                             //Hello ' + dataResult[x].name + ', you didn’t assign to training lesson for the next week
//                             notification: {
//                                 title: 'לא נרשמת לאימונים בשבוע הבא',
//                                 body: 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא '
//                             }
//                         });
//                         message.addData('message', 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא');
//                         message.addData('type', "Not_assign_user_lesson");
//                         message.addData('appname', "fitnessApp");
//                         message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                         var regTokens = [deviceToken];
//                         sender.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             else console.log(response);
//                             moment
//                         });
//                     } else if (dataResult[x].device_type == 'ios') {
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא'
//                         });
//                         var data1 = {};
//                         data1.type = "Not_assign_user_lesson";
//                         data1.data = 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא';
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.bizz.fitnessapp";
//                         note.type = "Not_assign_user_lesson";
//                         serviceIOS.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);
//                         });
//                         // For one-shot notification tasks you may wish to shutdown the connection
//                         // after everything is sent, but only call shutdown if you need your 
//                         // application to terminate.
//                         serviceIOS.shutdown();
//                     }
//                 }
//                 break;

//                 //Every FRiday PN Moshe
//                 case "Not_assign_user_lesson_moshe":
//                 //console.log("Not_assign_user_lesson");

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {
//                         console.log("friday Moshe test");
//                         //console.log("notification send");

//                         var deviceToken = dataResult[x].registration_token;
//                         var message = new gcm.Message({
//                             //You didn’t assign to training lesson for the next week
//                             //Hello ' + dataResult[x].name + ', you didn’t assign to training lesson for the next week
//                             notification: {
//                                 title: 'תזכורת',
//                                 body: 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא '
//                             }
//                         });
//                         message.addData('message', 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא');
//                         message.addData('type', "Not_assign_user_lesson_moshe");
//                         message.addData('appname', "Moshe");
//                         message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                         var regTokens = [deviceToken];
//                         sender19.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             else console.log(response);
//                             moment
//                         });
//                     } else if (dataResult[x].device_type == 'ios') {
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא'
//                         });
//                         var data1 = {};
//                         data1.type = "Not_assign_user_lesson_moshe";
//                         data1.data = 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא';
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.MosheCustomer";//Moshe App
//                         note.type = "Not_assign_user_lesson_moshe";
//                         serviceMosheCustomer.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);
//                         });
//                         // For one-shot notification tasks you may wish to shutdown the connection
//                         // after everything is sent, but only call shutdown if you need your 
//                         // application to terminate.
//                         serviceMosheCustomer.shutdown();
//                     }
//                 }
//                 break;

//             case "Not_assign_user_lesson_knockout":


//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {


//                         var deviceToken = dataResult[x].registration_token;
//                         var message = new gcm.Message({
//                             //You didn’t assign to training lesson for the next week
//                             //Hello ' + dataResult[x].name + ', you didn’t assign to training lesson for the next week
//                             notification: {
//                                 title: 'הודעה חדשה מנוקאאוט',
//                                 body: 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא '
//                             }
//                         });
//                         message.addData('message', 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא');
//                         message.addData('type', "Not_assign_user_lesson_knockout");
//                         message.addData('appname', "knockout");
//                         message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                         var regTokens = [deviceToken];
//                         sender7.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             else console.log(response);
//                             moment
//                         });
//                     } else if (dataResult[x].device_type == 'ios') {
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא'
//                         });
//                         var data1 = {};
//                         data1.type = "Not_assign_user_lesson_knockout";
//                         data1.data = 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא';
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.Knockout";
//                         note.type = "Not_assign_user_lesson_knockout";
//                         serviceknockout1.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);
//                         });
//                         // For one-shot notification tasks you may wish to shutdown the connection
//                         // after everything is sent, but only call shutdown if you need your 
//                         // application to terminate.
//                         serviceknockout1.shutdown();
//                     }
//                 }
//                 break;
//                 case "Not_assign_user_lesson_fitnessAppEng":


//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {


//                         var deviceToken = dataResult[x].registration_token;
//                         var message = new gcm.Message({
//                             //You didn’t assign to training lesson for the next week
//                             //Hello ' + dataResult[x].name + ', you didn’t assign to training lesson for the next week
//                             notification: {
//                                 title: 'You didn’t assign to training lesson for the next week',
//                                 body: 'Hello ' + dataResult[x].name + ', you didn’t assign to training lesson for the next week'
//                             }
//                         });
//                         message.addData('message', 'Hello ' + dataResult[x].name + ', you didn’t assign to training lesson for the next week');
//                         message.addData('type', "Not_assign_user_lesson");
//                         message.addData('appname', "fitnessAppEng");
//                         message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                         var regTokens = [deviceToken];
//                         sender11.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             else console.log(response);
//                             moment
//                         });
//                     } else if (dataResult[x].device_type == 'ios') {
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא'
//                         });
//                         var data1 = {};
//                         data1.type = "Not_assign_user_lesson_knockout";
//                         data1.data = 'שלום , ' + dataResult[x].name + ' ,לא נרשמת לשיעורים בשבוע הבא';
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.Knockout";
//                         note.type = "Not_assign_user_lesson_knockout";
//                         serviceknockout1.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);
//                         });
//                         // For one-shot notification tasks you may wish to shutdown the connection
//                         // after everything is sent, but only call shutdown if you need your 
//                         // application to terminate.
//                         serviceknockout1.shutdown();
//                     }
//                 }
//                 break;




//             case "send_Push_Message_ToAll":
//                 //console.log("message to all");
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             //console.error('Error:- ' + err.stack);
//                             return;
//                         }

//                         //console.log('Connected Id:- ' + connection1.threadId);
//                     });
//                     if (user_type == 'all') {


//                         //console.log("SELECT a.* from user_registration_token as a where a.`user_type`='customer' OR a.`user_type`='normal' and a.app_id=1 GROUP BY a.user_id");


//                         var queryStr = "SELECT * from user_registration_token as a where (`user_type`='customer' OR `user_type`='normal')";
//                     } else {
//                         var queryStr = "SELECT a.* from user_registration_token as a where a.`user_type`='customer' GROUP BY a.user_id";
//                     }
//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {

//                         } else {
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);
//                             for (x in dataResult) {
//                                 if (dataResult[x].device_type == 'android' && app_id_forsendPushMessageToAll == '1' && dataResult[x].app_id == '1' ) {
//                                     console.log(dataResult[x].registration_token);
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'הודעה חדשה ממיכל ממן',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToAll");
//                                     message.addData('appname', "fitnessApp");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else {
//                                            // console.log(response);
//                                         }
//                                     });
//                                 } else if (dataResult[x].device_type == 'android' && app_id_forsendPushMessageToAll == '7') {
//                                     //console.log(dataResult[x].registration_token);
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             //title: 'הודעה חדשה ממיכל ממן',
//                                             title: 'הודעה חדשה מנוקאאוט',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToAll");
//                                     message.addData('appname', "knockout");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender7.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else{
//                                           //console.log(response);  
//                                         } 
//                                     });
//                                 } else if (dataResult[x].device_type == 'android' && dataResult[x].app_id == '9' && app_id_forsendPushMessageToAll == '9') {
//                                     console.log(dataResult[x].registration_token);
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             //title: 'הודעה חדשה ממיכל ממן',
//                                             title: 'You have a message from manager',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToAll");
//                                     message.addData('appname', "fitnessAppEng");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender11.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else {
//                                           console.log(response);  
//                                         }
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios' && app_id_forsendPushMessageToAll == '1') {

//                                     var deviceToken = dataResult[x].registration_token;

//                                     var tokens = [deviceToken];


//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToAll";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.bizz.fitnessapp";
//                                     note.type = "send_Push_Message_ToAll";
//                                     serviceIOS.send(note, tokens).then(result => {
//                                         //console.log("sent:", result.sent.length);
//                                         //console.log("failed:", result.failed.length);
//                                         //console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceIOS.shutdown();
//                                 } else if (dataResult[x].device_type == 'ios' && app_id_forsendPushMessageToAll == '7') {
									

//                                     var deviceToken = dataResult[x].registration_token;

//                                     var tokens = [deviceToken];


//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToAll";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.Knockout";
//                                     note.type = "send_Push_Message_ToAll";
//                                     serviceknockout1.send(note, tokens).then(result => {
//                                         //console.log("sent:", result.sent.length);
//                                         //console.log("failed:", result.failed.length);
//                                         //console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceknockout1.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//             case "send_Push_Message_ToAll_bizzapp6":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }

//                         console.log('Connected Id:- ' + connection1.threadId);
//                     });
//                     var queryStr = "SELECT a.* from user_registration_token as a where a.`user_id`=0 AND a.app_id='" + user_type + "'";
//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {

//                         } else {
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);
//                             for (x in dataResult) {
//                                 if (dataResult[x].device_type == 'android') {
//                                     console.log(dataResult[x].registration_token);
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'ג חיון',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToAll_bizzapp6");
//                                     message.addData('appname', "bizzapp6");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender2.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToAll_bizzapp6";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.G.HAUN";
//                                     note.type = "send_Push_Message_ToAll_bizzapp6";
//                                     serviceBizz6.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceBizz6.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//             case "send_Push_Message_ToAll_poolapp2":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }

//                         console.log('Connected Id:- ' + user_type);
//                     });
//                     var queryStr = "SELECT a.* from user_registration_token as a where a.`user_id`=0 AND a.app_id='" + user_type + "' GROUP BY a.user_id";
//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {

//                         } else {
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);
//                             for (x in dataResult) {
//                                 console.log(dataResult[x].registration_token);
//                                 var deviceToken = dataResult[x].registration_token;
//                                 var message = new gcm.Message({
//                                     //You have a message from manager
//                                     notification: {
//                                         title: 'ספלאש בריכות שחייה',
//                                         body: message1
//                                     }
//                                 });
//                                 message.addData('message', message1);
//                                 message.addData('type', "send_Push_Message_ToAll_poolapp2");
//                                 message.addData('appname', "poolapp2");
//                                 message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                 var regTokens = [deviceToken];
//                                 sender3.send(message, {
//                                     registrationTokens: regTokens
//                                 }, function(err, response) {
//                                     if (err) console.error(err);
//                                     else console.log(response);
//                                 });
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//             case "send_Push_Message_ToAll_yazivapp":
//                 console.log("send_Push_Message_ToAll_yazivapp");
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }

//                         console.log('Connected Id:- ' + user_type);
//                     });

//                     console.log("SELECT a.* from user_registration_token as a where a.`user_id`=0 AND a.app_id='" + user_type + "' GROUP BY a.user_id");

//                     //var queryStr = "SELECT a.* from user_registration_token as a where a.`user_id`=0 AND a.app_id='" + user_type + "' GROUP BY a.user_id";
//                     var queryStr = "SELECT * from user_registration_token where app_id='" + user_type + "' and (user_type='customer' or user_type='normal')";

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {

//                         } else {
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);
//                             for (x in dataResult) {
//                                 if (dataResult[x].device_type == 'android') {
//                                     console.log(dataResult[x].registration_token);
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'יציב מרכז מזון',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToAll_yazivapp");
//                                     message.addData('appname', "yazivapp");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender4.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToAll_yazivapp";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.StableFoodCenter";
//                                     note.type = "send_Push_Message_ToAll_yazivapp";
//                                     serviceBizz7.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceBizz7.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//             case "send_Push_Message_ToAll_babyshick":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }

//                         console.log('Connected Id:- ' + user_type);
//                     });
//                     var queryStr = "SELECT a.* from user_registration_token as a where a.`user_id`=0 AND a.app_id='" + user_type + "'";
//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {

//                         } else {
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);
//                             for (x in dataResult) {
//                                 if (dataResult[x].device_type == 'android') {
//                                     console.log("babyshick Pushnotication Android " + dataResult[x].registration_token);
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'בייבי שיק',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToAll_babyshick");
//                                     message.addData('appname', "babyshick");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender5.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var tokens = [deviceToken];
//                                     var serviceIOS5 = new apn.Provider({
//                                         cert: "./resources/babyshic.pem",
//                                         key: "./resources/babyshic.pem",
//                                         production: false
//                                     }); //BabyShick App pem 
//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToAll_babyshick";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.babyshickapp";
//                                     note.type = "send_Push_Message_ToAll_babyshick";
//                                     serviceIOS5.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceIOS5.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;


//             case "send_Push_Message_ToSelectedCustomer":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     //console.log(selected_customer);

//                     //console.log("SELECT * FROM `user_registration_token` WHERE `user_id` IN (" + selected_customer + ") GROUP BY user_id");

//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE `user_id` IN (" + selected_customer + ") GROUP BY user_id";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android' && app_id_forsendPushMessageToAll == '1' && dataResult[x].app_id == '1') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'הודעה חדשה ממיכל ממן',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToAll");
//                                     message.addData('appname', "fitnessApp");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         /*if (err) console.error(err);
//                                         else console.log(response);*/
//                                     });
//                                 } else if (dataResult[x].device_type == 'android' && app_id_forsendPushMessageToAll == '7') {

//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'הודעה חדשה מנוקאאוט',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToAll");
//                                     message.addData('appname', "knockout");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender7.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         /*if (err) console.error(err);
//                                         else console.log(response);*/
//                                     });

//                                 } else if (dataResult[x].device_type == 'android' && app_id_forsendPushMessageToAll == '9' && dataResult[x].app_id == 9) {

//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'You have a message from manager',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToAll");
//                                     message.addData('appname', "fitnessAppEng");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender11.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });

//                                 } else if (dataResult[x].device_type == 'ios' && app_id_forsendPushMessageToAll == '1') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToAll";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.bizz.fitnessapp";
//                                     note.type = "send_Push_Message_ToAll";
//                                     serviceIOS.send(note, tokens).then(result => {
//                                         //console.log("sent:", result.sent.length);
//                                         //console.log("failed:", result.failed.length);
//                                         //console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceIOS.shutdown();
//                                 } else if (dataResult[x].device_type == 'ios' && app_id_forsendPushMessageToAll == '7') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToAll";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.Knockout";
//                                     note.type = "send_Push_Message_ToAll";
//                                     serviceknockout1.send(note, tokens).then(result => {
//                                         //console.log("sent:", result.sent.length);
//                                         //console.log("failed:", result.failed.length);
//                                         //console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceknockout1.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//             case "issue raised by customer":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     console.log("selected notification");
//                     console.log(selected_customer);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE `app_id`='"+user_type+"' and `user_type`='manager'";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'il Uzan',
//                                             body: 'התקבלה פנייה חדשה מ,'+message1
//                                         }
//                                     });
//                                     message.addData('message','התקבלה פנייה חדשה מ,'+message1);
//                                     message.addData('type', "raised_issue_by_customer");
//                                     message.addData('appname', "Uzan");
//                                     message.addData('name', message1);
//                                     message.addData('user_id', app_id_forsendPushMessageToAll);
//                                     message.addData('group_name', group_name);
//                                     message.addData('group_id', group_id);
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender13.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         /*if (err) console.error(err);
//                                         else console.log(response);*/
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: 'התקבלה פנייה חדשה מ,'+message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "raised_issue_by_customer";
//                                     data1.data = 'התקבלה פנייה חדשה מ,'+message1;
//                                     data1.group_id=group_id;
//                                     data1.group_name=group_name;
//                                     data1.user_id=app_id_forsendPushMessageToAll;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.mct.uzanApp";
//                                     note.type = "raised_issue_by_customer";
//                                     serviceUzanManager.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceUzanManager.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//             case "issue fixed by manager":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     console.log("selected notification");
//                     console.log(selected_customer);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE `app_id`='"+user_type+"' and `user_type`='customer' AND user_id='"+app_id_forsendPushMessageToAll+"'";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: ' י ל אוזן יזמות',
//                                             body: 'שלום , פנייתך טופלה'
//                                         }
//                                     });
//                                     message.addData('message', 'שלום , פנייתך טופלה');
//                                     message.addData('type', "fix_issue_by_manager");
//                                     message.addData('appname', "Uzan");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender12.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         /*if (err) console.error(err);
//                                         else console.log(response);*/
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: 'שלום , פנייתך טופלה'
//                                     });
//                                     var data1 = {};
//                                     data1.type = "fix_issue_by_manager";
//                                     data1.data = 'שלום , פנייתך טופלה';
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.UzanCustomer";
//                                     note.type = "fix_issue_by_manager";
//                                     serviceUzanCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceUzanCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;    
//             case "issue open by manager":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     console.log("selected notification");
//                     console.log(selected_customer);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE `app_id`='"+user_type+"' and `user_type`='customer' AND user_id='"+app_id_forsendPushMessageToAll+"'";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: ' י ל אוזן יזמות',
//                                             body: 'קריאתך הועברה לטיפול'
//                                         }
//                                     });
//                                     message.addData('message', 'קריאתך הועברה לטיפול');
//                                     message.addData('type', "open_issue_by_manager");
//                                     message.addData('appname', "Uzan");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender12.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         /*if (err) console.error(err);
//                                         else console.log(response);*/
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: 'קריאתך הועברה לטיפול'
//                                     });
//                                     var data1 = {};
//                                     data1.type = "open_issue_by_manager";
//                                     data1.data = 'קריאתך הועברה לטיפול';
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.UzanCustomer";
//                                     note.type = "open_issue_by_manager";
//                                     serviceUzanCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceUzanCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "issue fixed by user":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     console.log("selected notification");
//                     console.log(selected_customer);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE `app_id`='"+user_type+"' and `user_type`='manager'";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'il Uzan',
//                                             body: 'שלום, הבקשה טופלה על ידי הלקוח,'+message1
//                                         }
//                                     });
//                                     message.addData('message', 'שלום, הבקשה טופלה על ידי הלקוח,'+message1);
//                                     message.addData('type', "fix_issue_by_user");
//                                     message.addData('appname', "Uzan");
//                                     message.addData('name', message1);
//                                     message.addData('user_id', app_id_forsendPushMessageToAll);
//                                     message.addData('group_name', group_name);
//                                     message.addData('group_id', group_id);
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender13.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: 'שלום, הבקשה טופלה על ידי הלקוח,'+message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "fix_issue_by_user";
//                                     data1.data = 'שלום, הבקשה טופלה על ידי הלקוח,'+message1;
//                                     data1.group_id=group_id;
//                                     data1.group_name=group_name;
//                                     data1.user_id=app_id_forsendPushMessageToAll;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.mct.uzanApp";
//                                     note.type = "fix_issue_by_user";
//                                     serviceUzanManager.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceUzanManager.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_ToSelectedGroup_Uzan":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     console.log("selected notification");
//                     console.log(selected_customer);

                    
//                     var queryStr = "SELECT user_registration_token.* FROM `user_registration_token`,`userinfo` WHERE user_registration_token.user_id=userinfo.id AND user_registration_token.app_id='"+app_id_forsendPushMessageToAll+"' and user_registration_token.user_type='customer' AND userinfo.group_id='"+user_type+"'";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'י ל אוזן יזמות',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_Group_Uzan");
//                                     message.addData('appname', "Uzan");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender12.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_Group_Uzan";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.UzanCustomer";
//                                     note.type = "send_Push_Message_To_Group_Uzan";
//                                     serviceUzanCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceUzanCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_ToSelectedUser_Uzan":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE `user_id` IN (" + selected_customer + ") AND app_id='"+app_id_forsendPushMessageToAll+"' GROUP BY user_id";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'י ל אוזן יזמות',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_Selected_User_Uzan");
//                                     message.addData('appname', "Uzan");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender12.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_Selected_User_Uzan";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.UzanCustomer";
//                                     note.type = "send_Push_Message_To_Selected_User_Uzan";
//                                     serviceUzanCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceUzanCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_ToAll_Uzan":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+app_id_forsendPushMessageToAll+"' and (user_type='customer' OR user_type='normal')";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'י ל אוזן יזמות',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_All_User_Uzan");
//                                     message.addData('appname', "Uzan");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender12.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_All_User_Uzan";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.UzanCustomer";
//                                     note.type = "send_Push_Message_To_All_User_Uzan";
//                                     serviceUzanCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceUzanCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_allLoginUser_Uzan":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+app_id_forsendPushMessageToAll+"' and user_type='customer' GROUP BY user_id";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'י ל אוזן יזמות',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_All_User_Uzan");
//                                     message.addData('appname', "Uzan");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender12.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios all login users");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_All_User_Uzan";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.UzanCustomer";
//                                     note.type = "send_Push_Message_To_All_User_Uzan";
//                                     serviceUzanCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceUzanCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "birthday_notification":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             //you have a lesson in a hour
//                             //Hello ' + dataResult[x].name + ', you have a lesson in a hour
//                             notification: {
//                                 title: 'מזל טוב ליום הולדתך',
//                                 body: dataResult[x].name + ' ,יש לך שיעור בעוד שעה'
//                             }
//                         });
//                         message.addData('message', dataResult[x].name + ', מזל טוב ליום הולדתך');
//                         message.addData('type', "birthday_notification_uzan");
//                         message.addData('appname', "uzan");
//                         message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                         var regTokens = [deviceToken];
//                         sender12.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             console.log(response)
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                         console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה'
//                         });
//                         var data1 = {};
//                         data1.type = "birthday_notification_uzan";
//                         data1.data = dataResult[x].name + ' ,יש לך שיעור בעוד שעה';
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.UzanCustomer";
//                         note.type = "birthday_notification_uzan";
//                         serviceUzanCustomer.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         // For one-shot notification tasks you may wish to shutdown the connection
//                         // after everything is sent, but only call shutdown if you need your 
//                         // application to terminate.
                    
                       
//                         serviceUzanCustomer.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;

//                 //b'day safir
//                 case "birthday_notification_Safir":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             //you have a lesson in a hour
//                             //Hello ' + dataResult[x].name + ', you have a lesson in a hour
//                             notification: {
//                                 title: 'מזל טוב ליום הולדתך',
//                                 body: dataResult[x].name + ' ,יש לך שיעור בעוד שעה'
//                             }
//                         });
//                         message.addData('message', dataResult[x].name + ', מזל טוב ליום הולדתך');
//                         message.addData('type', "birthday_notification_Safir");
//                         message.addData('appname', "uzan");
//                         message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                         var regTokens = [deviceToken];
//                         sender12.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             console.log(response)
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                         console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: 'שלום , ' + dataResult[x].name + ' ,יש לך שיעור בעוד שעה'
//                         });
//                         var data1 = {};
//                         data1.type = "birthday_notification_Safir";
//                         data1.data = dataResult[x].name + ' ,יש לך שיעור בעוד שעה';
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.SafirCustomer";
//                         note.type = "birthday_notification_Safir";
//                         serviceSafirCustomer.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         // For one-shot notification tasks you may wish to shutdown the connection
//                         // after everything is sent, but only call shutdown if you need your 
//                         // application to terminate.
                    
                       
//                         serviceSafirCustomer.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;

//                 case "send_Push_Message_ToSelectedUser_Rabin":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE `user_id` IN (" + selected_customer + ") AND app_id='"+app_id_forsendPushMessageToAll+"' GROUP BY user_id";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                              //console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'בית ספר רבין אשדוד',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_Selected_User_Rabin");
//                                     message.addData('appname', "Rabin");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender14.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response+'Rabin');
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_Selected_User_Rabin";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.RabinCustomer";
//                                     note.type = "send_Push_Message_To_Selected_User_Rabin";
//                                     serviceRabinCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceRabinCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_ToSelectedGroup_Rabin":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     console.log("selected notification");
//                     console.log(selected_customer);

                    
//                     var queryStr = "SELECT user_registration_token.* FROM `user_registration_token`,`userinfo` WHERE user_registration_token.user_id=userinfo.id AND user_registration_token.app_id='"+app_id_forsendPushMessageToAll+"' and user_registration_token.user_type='customer' AND userinfo.group_id='"+user_type+"'";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'בית ספר רבין אשדוד',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_Group_Rabin");
//                                     message.addData('appname', "Rabin");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender14.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_Group_Rabin";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.RabinCustomer";
//                                     note.type = "send_Push_Message_To_Group_Rabin";
//                                     serviceRabinCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceRabinCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_allLoginUser_Rabin":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+app_id_forsendPushMessageToAll+"' and user_type='customer' GROUP BY user_id";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'בית ספר רבין אשדוד',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_All_Login_User_Rabin");
//                                     message.addData('appname', "Rabin");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender14.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_All_Login_User_Rabin";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.RabinCustomer";
//                                     note.type = "send_Push_Message_To_All_Login_User_Rabin";
//                                     serviceRabinCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceRabinCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_ToAll_Rabin":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+app_id_forsendPushMessageToAll+"' and (user_type='customer' OR user_type='normal')";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'בית ספר רבין אשדוד',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_All_User_Rabin");
//                                     message.addData('appname', "Rabin");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender14.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_All_User_Rabin";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.RabinCustomer";
//                                     note.type = "send_Push_Message_To_All_User_Rabin";
//                                     serviceRabinCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceRabinCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//                 case "send_Push_Message_ToSelectedUser_Rabin":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE `user_id` IN (" + selected_customer + ") AND app_id='"+app_id_forsendPushMessageToAll+"' GROUP BY user_id";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                              //console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'בית ספר רבין אשדוד',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_Selected_User_Rabin");
//                                     message.addData('appname', "Rabin");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender14.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response+'Rabin');
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_Selected_User_Rabin";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.RabinCustomer";
//                                     note.type = "send_Push_Message_To_Selected_User_Rabin";
//                                     serviceRabinCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceRabinCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_ToSelectedGroup_Rabin":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     console.log("selected notification");
//                     console.log(selected_customer);

                    
//                     var queryStr = "SELECT user_registration_token.* FROM `user_registration_token`,`userinfo` WHERE user_registration_token.user_id=userinfo.id AND user_registration_token.app_id='"+app_id_forsendPushMessageToAll+"' and user_registration_token.user_type='customer' AND userinfo.group_id='"+user_type+"'";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'בית ספר רבין אשדוד',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_Group_Rabin");
//                                     message.addData('appname', "Rabin");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender14.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_Group_Rabin";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.RabinCustomer";
//                                     note.type = "send_Push_Message_To_Group_Rabin";
//                                     serviceRabinCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceRabinCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_allLoginUser_Rabin":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+app_id_forsendPushMessageToAll+"' and user_type='customer' GROUP BY user_id";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'בית ספר רבין אשדוד',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_All_Login_User_Rabin");
//                                     message.addData('appname', "Rabin");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender14.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_All_Login_User_Rabin";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.RabinCustomer";
//                                     note.type = "send_Push_Message_To_All_Login_User_Rabin";
//                                     serviceRabinCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceRabinCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_ToAll_Rabin":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+app_id_forsendPushMessageToAll+"' and (user_type='customer' OR user_type='normal')";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'בית ספר רבין אשדוד',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_All_User_Rabin");
//                                     message.addData('appname', "Rabin");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender14.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_All_User_Rabin";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.RabinCustomer";
//                                     note.type = "send_Push_Message_To_All_User_Rabin";
//                                     serviceRabinCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceRabinCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//                 case "send_Push_Message_ToSelectedUser_safir":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE `user_id` IN (" + selected_customer + ") AND app_id='"+app_id_forsendPushMessageToAll+"' GROUP BY user_id";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                              //console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'safir',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToSelectedUser_safir");
//                                     message.addData('appname', "safir");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender21.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response+'safir');
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToSelectedUser_safir";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.SafirCustomer";
//                                     note.type = "send_Push_Message_ToSelectedUser_safir";
//                                     serviceSafirCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceSafirCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_ToSelectedGroup_safir":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     console.log("selected notification");
//                     console.log(selected_customer);

                    
//                     var queryStr = "SELECT user_registration_token.* FROM `user_registration_token`,`userinfo` WHERE user_registration_token.user_id=userinfo.id AND user_registration_token.app_id='"+app_id_forsendPushMessageToAll+"' and user_registration_token.user_type='customer' AND userinfo.group_id='"+user_type+"'";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'safir',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToSelectedGroup_safir");
//                                     message.addData('appname', "safir");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender21.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToSelectedGroup_safir";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.SafirCustomer";
//                                     note.type = "send_Push_Message_ToSelectedGroup_safir";
//                                     serviceSafirCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceSafirCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_allLoginUser_safir":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+app_id_forsendPushMessageToAll+"' and user_type='customer' GROUP BY user_id";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'safir',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_allLoginUser_safir");
//                                     message.addData('appname', "safir");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender21.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_allLoginUser_safir";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.SafirCustomer";
//                                     note.type = "send_Push_Message_allLoginUser_safir";
//                                     serviceSafirCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceSafirCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_ToAll_safir":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+app_id_forsendPushMessageToAll+"' and (user_type='customer' OR user_type='normal')";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'safir',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToAll_safir");
//                                     message.addData('appname', "safir");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender21.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToAll_safir";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.SafirCustomer";
//                                     note.type = "send_Push_Message_ToAll_safir";
//                                     serviceSafirCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceSafirCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//                 case "send_Push_Message_ToSelectedUser_nativ":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE `user_id` IN (" + selected_customer + ") AND app_id='"+app_id_forsendPushMessageToAll+"' GROUP BY user_id";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                              //console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 console.log(dataResult[x].user_id);
//                                 console.log(dataResult[x].device_type);
                                 
//                                 if (dataResult[x].device_type == 'android') {
//                                     console.log("sending to android");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'nativ',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToSelectedUser_nativ");
//                                     message.addData('appname', "nativ");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender23.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response+'nativ');
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToSelectedUser_nativ";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.NativCustomer";
//                                     note.type = "send_Push_Message_ToSelectedUser_nativ";
//                                     serviceNativCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceNativCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_ToSelectedGroup_nativ":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     console.log("selected notification");
//                     console.log(selected_customer);

                    
//                     var queryStr = "SELECT user_registration_token.* FROM `user_registration_token`,`userinfo` WHERE user_registration_token.user_id=userinfo.id AND user_registration_token.app_id='"+app_id_forsendPushMessageToAll+"' and user_registration_token.user_type='customer' AND userinfo.group_id='"+user_type+"'";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'nativ',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToSelectedGroup_nativ");
//                                     message.addData('appname', "nativ");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender23.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToSelectedGroup_nativ";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.NativCustomer";
//                                     note.type = "send_Push_Message_ToSelectedGroup_nativ";
//                                     serviceNativCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceNativCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_allLoginUser_nativ":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+app_id_forsendPushMessageToAll+"' and user_type='customer' GROUP BY user_id";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'nativ',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_allLoginUser_nativ");
//                                     message.addData('appname', "nativ");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender23.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_allLoginUser_nativ";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.NativCustomer";
//                                     note.type = "send_Push_Message_allLoginUser_nativ";
//                                     serviceNativCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceNativCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_ToAll_nativ":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+app_id_forsendPushMessageToAll+"' and (user_type='customer' OR user_type='normal')";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'nativ',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToAll_nativ");
//                                     message.addData('appname', "nativ");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender23.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToAll_nativ";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.NativCustomer";
//                                     note.type = "send_Push_Message_ToAll_nativ";
//                                     serviceNativCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceNativCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//                 case "birthday_notification_Rabin":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {

//                     /* var lesson_serverDateTime = moment.tz(new Date(), "Europe/Kiev").format("YYYY-MM-DD HH:mm:ss");
//                         var lesson_serverDateTime1 = moment.tz(new Date(), "Europe/Kiev").format();
//                         // console.log(lesson_serverDateTime+ "server time");
//                         var diff = Math.abs(new Date(dataResult[x].lesson_serverDateTime) - new Date(lesson_serverDateTime));
//                         var minutes = Math.floor((diff / 1000) / 60);
//                         //console.log(minutes +'-'+ dataResult[x].lesson_id);
//               if (dataResult[x].lesson_serverDateTime > new Date(lesson_serverDateTime)) {
//                             console.log("Got it");
//                         }
                        
//                         console.log(minutes); */

//                     //if (minutes==60 && (dataResult[x].lesson_serverDateTime > new Date(lesson_serverDateTime)) && dataResult[x].one_hour_before==0) {
//                     //if (minutes==186) {

//                     /* if (minutes==60 && (dataResult[x].lesson_serverDateTime > new Date(lesson_serverDateTime))) { */

//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             //you have a lesson in a hour
//                             //Hello ' + dataResult[x].name + ', you have a lesson in a hour
//                             notification: {
//                                 title: 'בית ספר רבין אשדוד',
//                                 body: 'מזל טוב ליום הולדתך'
//                             }
//                         });
//                         message.addData('message', 'מזל טוב ליום הולדתך');
//                         message.addData('type', "birthday_notification_Rabin");
//                         message.addData('appname', "Rabin");
//                         message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                         var regTokens = [deviceToken];
//                         sender14.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             console.log(response)
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                           console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: 'מזל טוב ליום הולדתך'
//                         });
//                         var data1 = {};
//                         data1.type = "birthday_notification_Rabin";
//                         data1.data = 'מזל טוב ליום הולדתך';
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.RabinCustomer";
//                         note.type = "birthday_notification_Rabin";
//                         serviceRabinCustomer.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         // For one-shot notification tasks you may wish to shutdown the connection
//                         // after everything is sent, but only call shutdown if you need your 
//                         // application to terminate.
                    
                       
//                         serviceRabinCustomer.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;

//                 case "send_Push_Message_ToSelectedUser_Hibuki":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE `user_id` IN (" + selected_customer + ") AND app_id='"+app_id_forsendPushMessageToAll+"' GROUP BY user_id";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'גן חיבוקי',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_Selected_User_Hibuki");
//                                     message.addData('appname', "Hibuki");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender15.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_Selected_User_Hibuki";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.KindergardenAppliaction";
//                                     note.type = "send_Push_Message_To_Selected_User_Hibuki";
//                                     serviceHibukiCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceHibukiCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_ToSelectedGroup_Hibuki":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     console.log("selected notification");
//                     console.log(selected_customer);

                    
//                     var queryStr = "SELECT user_registration_token.* FROM `user_registration_token`,`userinfo` WHERE user_registration_token.user_id=userinfo.id AND user_registration_token.app_id='"+app_id_forsendPushMessageToAll+"' and user_registration_token.user_type='customer' AND userinfo.group_id='"+user_type+"'";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'גן חיבוקי',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_Group_Hibuki");
//                                     message.addData('appname', "Hibuki");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender15.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_Group_Hibuki";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.KindergardenAppliaction";
//                                     note.type = "send_Push_Message_To_Group_Hibuki";
//                                     serviceHibukiCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceHibukiCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "send_Push_Message_allLoginUser_Hibuki":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+app_id_forsendPushMessageToAll+"' and user_type='customer' GROUP BY user_id";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'גן חיבוקי',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_All_login_User_Hibuki");
//                                     message.addData('appname', "Hibuki");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender15.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios all login users");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_All_login_User_Hibuki";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.KindergardenAppliaction";
//                                     note.type = "send_Push_Message_To_All_login_User_Hibuki";
//                                     serviceHibukiCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceHibukiCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;
//                 case "birthday_notification_Hibuki":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {

//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             notification: {
//                                 title: ' גן חיבוקי',
//                                 body: 'מזל טוב ליום הולדתך'
//                             }
//                         });
//                         message.addData('message', 'מזל טוב ליום הולדתך');
//                         message.addData('type', "birthday_notification_Hibuki");
//                         message.addData('appname', "Hibuki");
//                         message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                         var regTokens = [deviceToken];
//                         sender15.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             console.log(response)
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                           console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: 'מזל טוב ליום הולדתך'
//                         });
//                         var data1 = {};
//                         data1.type = "birthday_notification_Hibuki";
//                         data1.data = 'מזל טוב ליום הולדתך';
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.KindergardenAppliaction";
//                         note.type = "birthday_notification_Hibuki";
//                         serviceHibukiCustomer.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
                                         
                       
//                         serviceHibukiCustomer.shutdown();
//                     }
                    

//                 }
//                 break;

//                 case "send_Push_Message_ToAll_Hibuki":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+app_id_forsendPushMessageToAll+"' and (user_type='customer' OR user_type='normal')";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                             // console.log('no data');
//                         } else {
//                             // console.log(results);
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);

//                             for (x in dataResult) {
//                                 //console.log(dataResult[x].user_id);
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         //You have a message from manager
//                                         notification: {
//                                             title: 'גן חיבוקי',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_All_User_Hibuki");
//                                     message.addData('appname', "Hibuki");
//                                     message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                     var regTokens = [deviceToken];
//                                     sender15.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(dataResult[x].registration_token+"Send Successfully");
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_All_User_Hibuki";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.KindergardenAppliaction";
//                                     note.type = "send_Push_Message_To_All_User_Hibuki";
//                                     serviceHibukiCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceHibukiCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//                 //ADEL APP NOTOFICATION
//                 case "sendPushMessageToAdel":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }

//                         console.log('Connected Id:- ' + user_type);
//                     });
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+user_type+"' and (user_type='customer' OR user_type='normal')";
//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {

//                         } else {
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);
//                             for (x in dataResult) {
//                                 if (dataResult[x].device_type == 'android') {

//                                     console.log(dataResult[x].registration_token);
//                                 var deviceToken = dataResult[x].registration_token;
//                                 var message = new gcm.Message({
//                                     //You have a message from manager
//                                     notification: {
//                                         title: 'אדל בריכות שחייה',
//                                         body: message1
//                                     }
//                                 });
//                                 message.addData('message', message1);
//                                 message.addData('type', "sendPushMessageToAdel");
//                                 message.addData('appname', "Adel");
//                                 message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                 var regTokens = [deviceToken];
//                                 sender16.send(message, {
//                                     registrationTokens: regTokens
//                                 }, function(err, response) {
//                                     if (err) console.error(err);
//                                     else console.log(response);
//                                 });
//                             }else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "sendPushMessageToAdel";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.adelApp";
//                                     note.type = "sendPushMessageToAdel";
//                                     serviceAdelCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceAdelCustomer.shutdown();
//                                 }
                                
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//                 //neta PN
//                 case "sendPushMessageToNeta":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }

//                         console.log('Connected Id:- ' + user_type);
//                     });
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+user_type+"' and (user_type='customer' OR user_type='normal')";
//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {

//                         } else {
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);
//                             for (x in dataResult) {
//                                 if (dataResult[x].device_type == 'android') {

//                                     console.log(dataResult[x].registration_token);
//                                 var deviceToken = dataResult[x].registration_token;
//                                 var message = new gcm.Message({
//                                     //You have a message from manager
//                                     notification: {
//                                         title: 'Neta',
//                                         body: message1
//                                     }
//                                 });
//                                 message.addData('message', message1);
//                                 message.addData('type', "sendPushMessageToNeta");
//                                 message.addData('appname', "Neta");
//                                 message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                 var regTokens = [deviceToken];
//                                 sender20.send(message, {
//                                     registrationTokens: regTokens
//                                 }, function(err, response) {
//                                     if (err) console.error(err);
//                                     else console.log(response);
//                                 });
//                             }else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "sendPushMessageToNeta";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     // The topic is usually the bundle identifier of your application.
//                                     note.topic = "com.Bizz.netaApp";
//                                     note.type = "sendPushMessageToNeta";
//                                     serviceNetaCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     // For one-shot notification tasks you may wish to shutdown the connection
//                                     // after everything is sent, but only call shutdown if you need your 
//                                     // application to terminate.
//                                     serviceNetaCustomer.shutdown();
//                                 }
                                
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//                 //Deckon Notification
//                 case "sendPushMessageToDeckon":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }

//                         console.log('Connected Id:- ' + user_type);
//                     });
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+user_type+"' and (user_type='customer' OR user_type='normal')";
//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {

//                         } else {
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);
//                             for (x in dataResult) {
//                                  if (dataResult[x].device_type == 'android') {
//                                     console.log(dataResult[x].registration_token);
//                                 var deviceToken = dataResult[x].registration_token;
//                                 var message = new gcm.Message({
//                                     //You have a message from manager
//                                     notification: {
//                                         title: 'דקו דק',
//                                         body: message1
//                                     }
//                                 });
//                                 message.addData('message', message1);
//                                 message.addData('type', "sendPushMessageToDeckon");
//                                 message.addData('appname', "Deckon");
//                                 message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                 var regTokens = [deviceToken];
//                                 sender17.send(message, {
//                                     registrationTokens: regTokens
//                                 }, function(err, response) {
//                                     if (err) console.error(err);
//                                     else console.log(response);
//                                 });
//                             }else if(dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "sendPushMessageToDeckon";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     note.topic = "com.Bizz.deckApp";
//                                     note.type = "sendPushMessageToDeckon";
//                                     serviceDeckonCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     serviceDeckonCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//                 //sivan notification

//                  case "sendPushMessageToSivan":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }

//                         console.log('Connected Id:- ' + user_type);
//                     });
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+user_type+"' and (user_type='customer' OR user_type='normal')";
//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {

//                         } else {
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);
//                             for (x in dataResult) {
//                                  if (dataResult[x].device_type == 'android') {
//                                     console.log(dataResult[x].registration_token);
//                                 var deviceToken = dataResult[x].registration_token;
//                                 var message = new gcm.Message({
//                                     //You have a message from manager
//                                     notification: {
//                                         title: 'דקו דק',
//                                         body: message1
//                                     }
//                                 });
//                                 message.addData('message', message1);
//                                 message.addData('type', "sendPushMessageToSivan");
//                                 message.addData('appname', "Sivan");
//                                 message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                 var regTokens = [deviceToken];
//                                 sender25.send(message, {
//                                     registrationTokens: regTokens
//                                 }, function(err, response) {
//                                     if (err) console.error(err);
//                                     else console.log(response);
//                                 });
//                             }else if(dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "sendPushMessageToSivan";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     note.topic = "com.Bizz.SivanApp";
//                                     note.type = "sendPushMessageToSivan";
//                                     serviceSivanCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     serviceSivanCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//                 //Ashdodhayom notification

//                  case "sendPushMessageToAshdodhayom":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }

//                         console.log('Connected Id:- ' + user_type);
//                     });
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+user_type+"' and (user_type='customer' OR user_type='normal')";
//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {

//                         } else {
//                             var dataResult = results;
//                             //var dataResult=JSON.parse(dataResult);
//                             for (x in dataResult) {
//                                  if (dataResult[x].device_type == 'android') {
//                                     console.log(dataResult[x].registration_token);
//                                 var deviceToken = dataResult[x].registration_token;
//                                 var message = new gcm.Message({
//                                     //You have a message from manager
//                                     notification: {
                                       
//                                         body: message1
//                                     }
//                                 });
//                                 message.addData('message', message1);
//                                 message.addData('type', "sendPushMessageToAshdodhayom");
//                                 message.addData('appname', "Sivan");
//                                 message.timeToLive = 3000; // Duration in seconds to hold in GCM and retry before timing out. Default 4 weeks (2,419,200 seconds) if not specified.
//                                 var regTokens = [deviceToken];
//                                 sender24.send(message, {
//                                     registrationTokens: regTokens
//                                 }, function(err, response) {
//                                     if (err) console.error(err);
//                                     else console.log(response);
//                                 });
//                             }else if(dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "sendPushMessageToSivan";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     note.topic = "com.mct.ashdodhay";
//                                     note.type = "sendPushMessageToAshdodhayom";
//                                     serviceAshdodhayCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     serviceAshdodhayCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });

//                     // connection1.end();

//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//                 //push notification Moshe
//                 case "send_Push_Message_ToSelectedUser_moshe":
//                 try {
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                     });

//                     var selected_customer = user_type;
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE `user_id` IN (" + selected_customer + ") AND app_id='"+app_id_forsendPushMessageToAll+"' GROUP BY user_id";
//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                         } else {
//                             var dataResult = results;
//                             for (x in dataResult) {
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         notification: {
//                                             title: 'משה פרץ בית ספר לגלישה',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToSelectedUser_Moshe");
//                                     message.addData('appname', "Moshe");
//                                     message.timeToLive = 3000;
//                                     var regTokens = [deviceToken];
//                                     sender19.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToSelectedUser_Moshe";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     note.topic = "com.Bizz.MosheCustomer";
//                                     note.type = "send_Push_Message_ToSelectedUser_Moshe";
//                                     serviceMosheCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     serviceMosheCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });
//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

                

//                 //push notification Moshe
//                 case "send_Push_Message_ToSelectedUser_moshe":
//                 try {
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                     });

//                     var selected_customer = user_type;
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE `user_id` IN (" + selected_customer + ") AND app_id='"+app_id_forsendPushMessageToAll+"' GROUP BY user_id";
//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                         } else {
//                             var dataResult = results;
//                             for (x in dataResult) {
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         notification: {
//                                             title: 'משה פרץ בית ספר לגלישה',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToSelectedUser_Moshe");
//                                     message.addData('appname', "Moshe");
//                                     message.timeToLive = 3000;
//                                     var regTokens = [deviceToken];
//                                     sender19.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToSelectedUser_Moshe";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     note.topic = "com.Bizz.MosheCustomer";
//                                     note.type = "send_Push_Message_ToSelectedUser_Moshe";
//                                     serviceMosheCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     serviceMosheCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });
//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//                 //
//                 case "send_Push_Message_ToSelectedGroup_moshe":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                     });

//                     var selected_customer = user_type;
//                     console.log("selected notification");
//                     console.log(selected_customer);
//                     var queryStr = "SELECT user_registration_token.* FROM `user_registration_token`,`userinfo` WHERE user_registration_token.user_id=userinfo.id AND user_registration_token.app_id='"+app_id_forsendPushMessageToAll+"' and user_registration_token.user_type='customer' AND userinfo.group_id='"+user_type+"'";

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                         } else {
//                             var dataResult = results;
//                             for (x in dataResult) {
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
                                        
//                                         notification: {
//                                             title: 'משה פרץ בית ספר לגלישה',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToSelectedGroup_moshe");
//                                     message.addData('appname', "Moshe");
//                                     message.timeToLive = 3000;
//                                     var regTokens = [deviceToken];
//                                     sender19.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToSelectedGroup_moshe";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     note.topic = "com.Bizz.MosheCustomer";
//                                     note.type = "send_Push_Message_ToSelectedGroup_moshe";
//                                     serviceMosheCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     serviceMosheCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });
//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//                 //Moshe all login user
//                 case "send_Push_Message_allLoginUser_moshe":
//                 try {
//                     //connection1.connect();
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                         // console.log('Connected Id:- ' + connection1.threadId);
//                     });

//                     var selected_customer = user_type;
//                     //console.log("selected notification");
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+app_id_forsendPushMessageToAll+"' and user_type='customer' GROUP BY user_id";
//                     //console.log(queryStr);

//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                         } else {
//                             var dataResult = results;
//                             for (x in dataResult) {
//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         notification: {
//                                             title: 'משה פרץ בית ספר לגלישה',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_allLoginUser_moshe");
//                                     message.addData('appname', "Moshe");
//                                     message.timeToLive = 3000; 
//                                     var regTokens = [deviceToken];
//                                     sender19.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios all login users");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_allLoginUser_moshe";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     note.topic = "com.Bizz.MosheCustomer";
//                                     note.type = "send_Push_Message_allLoginUser_moshe";
//                                     serviceMosheCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     serviceMosheCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });
//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//                 //Scheduled PN to Natzrat
//                 case "scheduled_push_notification_natzrat":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             notification: {
//                                 title: 'Natzrat',
//                                 body: dataResult[x].pn_text
//                             }
//                         });
//                         message.addData('message', dataResult[x].pn_text);
//                         message.addData('type', "scheduled_push_notification_natzrat");
//                         message.addData('appname', "Natzrat");
//                         message.timeToLive = 3000;
//                         var regTokens = [deviceToken];
//                         sender18.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             console.log(response)
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                         console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: dataResult[x].pn_text
//                         });
//                         var data1 = {};
//                         data1.type = "scheduled_push_notification_natzrat";
//                         data1.data = dataResult[x].pn_text;
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.NatzratCustChange";
//                         note.type = "scheduled_push_notification_natzrat";
//                         serviceNatzratCustomer.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         serviceNatzratCustomer.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;

//                 //Scheduled PN to Rafael
//                 case "scheduled_push_notification_rafael":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             notification: {
//                                 title: 'Rafael',
//                                 body: dataResult[x].pn_text
//                             }
//                         });
//                         message.addData('message', dataResult[x].pn_text);
//                         message.addData('type', "scheduled_push_notification_rafael");
//                         message.addData('appname', "Rafael");
//                         message.timeToLive = 3000;
//                         var regTokens = [deviceToken];
//                         sender22.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             console.log(response)
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                         console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: dataResult[x].pn_text
//                         });
//                         var data1 = {};
//                         data1.type = "scheduled_push_notification_rafael";
//                         data1.data = dataResult[x].pn_text;
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.RafaelCustomer";
//                         note.type = "scheduled_push_notification_rafael";
//                         serviceRafaelCustomer.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         serviceRafaelCustomer.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;

//                 case "scheduled_push_notification_safir_all_user":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             notification: {
//                                 title: 'Safir',
//                                 body: dataResult[x].pn_text
//                             }
//                         });
//                         message.addData('message', dataResult[x].pn_text);
//                         message.addData('type', "scheduled_push_notification_safir_all_user");
//                         message.addData('appname', "Safir");
//                         message.timeToLive = 3000;
//                         var regTokens = [deviceToken];
//                         sender21.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             console.log(response)
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                         console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: dataResult[x].pn_text
//                         });
//                         var data1 = {};
//                         data1.type = "scheduled_push_notification_safir_all_user";
//                         data1.data = dataResult[x].pn_text;
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.SafirCustomer";
//                         note.type = "scheduled_push_notification_safir_all_user";
//                         serviceSafirCustomer.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         serviceSafirCustomer.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;

//                 case "scheduled_push_notification_nativ_all_user":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             notification: {
//                                 title: 'Nativ',
//                                 body: dataResult[x].pn_text
//                             }
//                         });
//                         message.addData('message', dataResult[x].pn_text);
//                         message.addData('type', "scheduled_push_notification_nativ_all_user");
//                         message.addData('appname', "Nativ");
//                         message.timeToLive = 3000;
//                         var regTokens = [deviceToken];
//                         sender23.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             console.log(response)
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                         console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: dataResult[x].pn_text
//                         });
//                         var data1 = {};
//                         data1.type = "scheduled_push_notification_nativ_all_user";
//                         data1.data = dataResult[x].pn_text;
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.NativCustomer";
//                         note.type = "scheduled_push_notification_nativ_all_user";
//                         serviceNativCustomer.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         serviceNativCustomer.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;

//                 case "scheduled_push_notification_safir_all_login_user":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             notification: {
//                                 title: 'Safir',
//                                 body: dataResult[x].pn_text
//                             }
//                         });
//                         message.addData('message', dataResult[x].pn_text);
//                         message.addData('type', "scheduled_push_notification_safir_all_login_user");
//                         message.addData('appname', "Safir");
//                         message.timeToLive = 3000;
//                         var regTokens = [deviceToken];
//                         sender21.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             console.log(response)
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                         console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: dataResult[x].pn_text
//                         });
//                         var data1 = {};
//                         data1.type = "scheduled_push_notification_safir_all_login_user";
//                         data1.data = dataResult[x].pn_text;
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.SafirCustomer";
//                         note.type = "scheduled_push_notification_safir_all_login_user";
//                         serviceSafirCustomer.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         serviceSafirCustomer.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;

//                 case "scheduled_push_notification_nativ_all_login_user":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             notification: {
//                                 title: 'Nativ',
//                                 body: dataResult[x].pn_text
//                             }
//                         });
//                         message.addData('message', dataResult[x].pn_text);
//                         message.addData('type', "scheduled_push_notification_nativ_all_login_user");
//                         message.addData('appname', "Nativ");
//                         message.timeToLive = 3000;
//                         var regTokens = [deviceToken];
//                         sender23.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             console.log(response)
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                         console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: dataResult[x].pn_text
//                         });
//                         var data1 = {};
//                         data1.type = "scheduled_push_notification_nativ_all_login_user";
//                         data1.data = dataResult[x].pn_text;
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.NativCustomer";
//                         note.type = "scheduled_push_notification_nativ_all_login_user";
//                         serviceNativCustomer.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         serviceNativCustomer.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;

//                 case "scheduled_push_notification_safir_selected_users":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             notification: {
//                                 title: 'Safir',
//                                 body: dataResult[x].pn_text
//                             }
//                         });
//                         message.addData('message', dataResult[x].pn_text);
//                         message.addData('type', "scheduled_push_notification_safir_selected_users");
//                         message.addData('appname', "Safir");
//                         message.timeToLive = 3000;
//                         var regTokens = [deviceToken];
//                         sender21.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             console.log(response)
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                         console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: dataResult[x].pn_text
//                         });
//                         var data1 = {};
//                         data1.type = "scheduled_push_notification_safir_selected_users";
//                         data1.data = dataResult[x].pn_text;
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.SafirCustomer";
//                         note.type = "scheduled_push_notification_safir_selected_users";
//                         serviceSafirCustomer.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         serviceSafirCustomer.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;

//                 case "scheduled_push_notification_nativ_selected_users":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             notification: {
//                                 title: 'Nativ',
//                                 body: dataResult[x].pn_text
//                             }
//                         });
//                         message.addData('message', dataResult[x].pn_text);
//                         message.addData('type', "scheduled_push_notification_nativ_selected_users");
//                         message.addData('appname', "Nativ");
//                         message.timeToLive = 3000;
//                         var regTokens = [deviceToken];
//                         sender23.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             console.log(response)
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                         console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: dataResult[x].pn_text
//                         });
//                         var data1 = {};
//                         data1.type = "scheduled_push_notification_nativ_selected_users";
//                         data1.data = dataResult[x].pn_text;
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.NativCustomer";
//                         note.type = "scheduled_push_notification_nativ_selected_users";
//                         serviceNativCustomer.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         serviceNativCustomer.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;

//                 case "scheduled_push_notification_safir_group":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             notification: {
//                                 title: 'Safir',
//                                 body: dataResult[x].pn_text
//                             }
//                         });
//                         message.addData('message', dataResult[x].pn_text);
//                         message.addData('type', "scheduled_push_notification_safir_group");
//                         message.addData('appname', "Safir");
//                         message.timeToLive = 3000;
//                         var regTokens = [deviceToken];
//                         sender21.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             console.log(response)
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                         console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: dataResult[x].pn_text
//                         });
//                         var data1 = {};
//                         data1.type = "scheduled_push_notification_safir_group";
//                         data1.data = dataResult[x].pn_text;
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.SafirCustomer";
//                         note.type = "scheduled_push_notification_safir_group";
//                         serviceSafirCustomer.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         serviceSafirCustomer.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;

//                 case "scheduled_push_notification_nativ_group":

//                 var dataResult = JSON.parse(dataResult);
//                 for (x in dataResult) {
//                     if (dataResult[x].device_type == 'android') {
//                         var deviceToken = dataResult[x].registration_token;
//                         console.log(deviceToken + "-Android");
//                         var message = new gcm.Message({
//                             notification: {
//                                 title: 'Nativ',
//                                 body: dataResult[x].pn_text
//                             }
//                         });
//                         message.addData('message', dataResult[x].pn_text);
//                         message.addData('type', "scheduled_push_notification_nativ_group");
//                         message.addData('appname', "Nativ");
//                         message.timeToLive = 3000;
//                         var regTokens = [deviceToken];
//                         sender23.send(message, {
//                             registrationTokens: regTokens
//                         }, function(err, response) {
//                             if (err) console.error(err);
//                             console.log(response)
//                         });

//                     } else if (dataResult[x].device_type == 'ios') {
//                         console.log(deviceToken + "-Ios");
//                         var deviceToken = dataResult[x].registration_token;
//                         var tokens = [deviceToken];

//                         var note = new apn.Notification({
//                             alert: dataResult[x].pn_text
//                         });
//                         var data1 = {};
//                         data1.type = "scheduled_push_notification_nativ_group";
//                         data1.data = dataResult[x].pn_text;
//                         note.payload = data1;
//                         // The topic is usually the bundle identifier of your application.
//                         note.topic = "com.Bizz.NativCustomer";
//                         note.type = "scheduled_push_notification_nativ_group";
//                         serviceNativCustomer.send(note, tokens).then(result => {
//                             console.log("sent:", result.sent.length);
//                             console.log("failed:", result.failed.length);
//                             console.log(result.failed);


//                         });
//                         serviceNativCustomer.shutdown();
//                     }
//                     /* }  */

//                 }
//                 break;

//                 //PN to all Moshe
//                 case "send_Push_Message_ToAll_moshe":
//                 try {
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                     });

//                     var selected_customer = user_type;
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+app_id_forsendPushMessageToAll+"' and (user_type='customer' OR user_type='normal')";
//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                         } else {
//                             var dataResult = results;
//                             for (x in dataResult) {

//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         notification: {
//                                             title: 'משה פרץ בית ספר לגלישה',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_ToAll_moshe");
//                                     message.addData('appname', "Moshe");
//                                     message.timeToLive = 3000; 
//                                     var regTokens = [deviceToken];
//                                     sender19.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_ToAll_moshe";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     note.topic = "com.Bizz.MosheCustomer";
//                                     note.type = "send_Push_Message_ToAll_moshe";
//                                     serviceMosheCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     serviceMosheCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });
//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//                 case "send_Push_Message_To_All_Natzrat":
//                 try {
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                     });

//                     var selected_customer = user_type;
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+app_id_forsendPushMessageToAll+"' and (user_type='customer' OR user_type='normal')";
//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                         } else {
//                             var dataResult = results;
//                             for (x in dataResult) {

//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         notification: {
//                                             title: 'Natzrat',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_All_Natzrat");
//                                     message.addData('appname', "Moshe");
//                                     message.timeToLive = 3000; 
//                                     var regTokens = [deviceToken];
//                                     sender18.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios natzrat");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_All_Natzrat";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     note.topic = "com.Bizz.NatzratCustChange";
//                                     note.type = "send_Push_Message_To_All_Natzrat";
//                                     serviceNatzratCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     serviceNatzratCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });
//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;

//                 case "send_Push_Message_To_All_Rafael":
//                 try {
//                     connection1.connect(function(err) {
//                         if (err) {
//                             console.error('Error:- ' + err.stack);
//                             return;
//                         }
//                     });

//                     var selected_customer = user_type;
//                     console.log(user_type);

                    
//                     var queryStr = "SELECT * FROM `user_registration_token` WHERE app_id='"+app_id_forsendPushMessageToAll+"' and (user_type='customer' OR user_type='normal')";
//                     connection1.query(queryStr, function(error, results, fields) {
//                         if (error) throw error;
//                         if (results == '') {
//                         } else {
//                             var dataResult = results;
//                             for (x in dataResult) {

//                                 if (dataResult[x].device_type == 'android') {
//                                     var deviceToken = dataResult[x].registration_token;
//                                     var message = new gcm.Message({
//                                         notification: {
//                                             title: 'Rafael',
//                                             body: message1
//                                         }
//                                     });
//                                     message.addData('message', message1);
//                                     message.addData('type', "send_Push_Message_To_All_Rafael");
//                                     message.addData('appname', "Rafael");
//                                     message.timeToLive = 3000; 
//                                     var regTokens = [deviceToken];
//                                     sender22.send(message, {
//                                         registrationTokens: regTokens
//                                     }, function(err, response) {
//                                         if (err) console.error(err);
//                                         else console.log(response);
//                                     });
//                                 } else if (dataResult[x].device_type == 'ios') {
//                                     console.log("sending to ios rafael");
//                                     var deviceToken = dataResult[x].registration_token;
//                                     console.log(deviceToken);
//                                     var tokens = [deviceToken];

//                                     var note = new apn.Notification({
//                                         alert: message1
//                                     });
//                                     var data1 = {};
//                                     data1.type = "send_Push_Message_To_All_Rafael";
//                                     data1.data = message1;
//                                     note.payload = data1;
//                                     note.topic = "com.Bizz.RafaelCustomer";
//                                     note.type = "send_Push_Message_To_All_Rafael";
//                                     serviceRafaelCustomer.send(note, tokens).then(result => {
//                                         console.log("sent:", result.sent.length);
//                                         console.log("failed:", result.failed.length);
//                                         console.log(result.failed);
//                                     });
//                                     serviceRafaelCustomer.shutdown();
//                                 }
//                             }
//                         }
//                     });
//                 } catch (ex) {
//                     console.error("Internal error:" + ex);
//                     return next(ex);
//                 }
//                 break;


//             case "autoNotification":
//                 //console.log(date_format(new Date(),'%H:%i:%s'));
//                 var deviceToken = "ba8cd9e147140e377b0ee1859876cfef8b6b8c311cf427dab8382bb70be2f610";
//                 var tokens = [deviceToken];

//                 var note = new apn.Notification({
//                     alert: "First notification msg"
//                 });
//                 var data1 = {};
//                 data1.type = "Testing notification";
//                 data1.data = "first Notification data";
//                 note.payload = data1;
//                 // The topic is usually the bundle identifier of your application.
//                 note.topic = "com.bizz.fitnessapp";
//                 note.type = "Testing notification note";
//                 serviceIOS.send(note, tokens).then(result => {
//                     console.log("sent:", result.sent.length);
//                     console.log("failed:", result.failed.length);
//                     console.log(result.failed);
//                 });
//                 // For one-shot notification tasks you may wish to shutdown the connection
//                 // after everything is sent, but only call shutdown if you need your 
//                 // application to terminate.
//                 serviceIOS.shutdown();

//                 break;

//             default:
//                 console.log(2);
//         }
//     }
   
//     module.exports = fcmPushnotification;